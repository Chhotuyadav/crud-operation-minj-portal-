
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Model{


	//login

	public function login_user($email,$password){
		 $this->db->where('email', $email);
        $this->db->where('password', $password);
        $query = $this->db->get('user_login');
			//return $query->result();
			if ($query->num_rows()) {
				
				return $query->row()->id; 
			}
			else{
				return false;
			}
    	
	}

	//forgot -email

	public function forgot_email($email){

		$this->db->where('email',$email);
		$get = $this->db->get('user_login');
		return $get->result();

	}
    

	// chnge password

	public function change_password($password){
		$id=$_SESSION['id_'];
		$this->db->set('password',$password);
		$this->db->where('id',$id);
		$this->db->update('user_login');
		return true;
	}

    //enquiry
    function saverecords($data)
	{
        $this->db->insert('enquiry',$data);
        return true;
	}  

   //pay fee
	function savepayfee($data){
		$this->db->insert('payfee',$data);
		return true;
	}

	//batch

	function batch($data){
		$this->db->insert('batch',$data);
		return true;

	}

	//fellow_up
	public function fellow_up($data){
		$this->db->insert('fellow_up',$data);

		return true;
	}

	//placment
	function placment($data){
		$this->db->insert('placment_opening',$data);
		return true;

	}

	////current opining

	function c_opening($data){
		$this->db->insert('current_opening',$data);
		return true;

	}

	//feedback

	function feedback($data){
		$this->db->insert('feedback',$data);
		return true;

	}

	

	/*display record*/

		public function enquiry_data_display(){
			 $this->db->select('*');
    		 $this->db->where('follow_d', date('y-m-d'));
			$query = $this->db->get('enquiry');
			return $query->result();
		}

		//due payment remainder

		public function get_due_payment_remainder(){
			$this->db->select('*');
			$this->db->where('due_date',date('y-m-d'));
			$query = $this->db->get('payfee');
			return $query->result();
		}

		//brochure

		 function do_upload($data)
		{
			$this->db->insert('brochure',$data);
			return true;		
		}

		public function brochure_get(){

			$this->db->order_by('id','desc');
			$query = $this->db->get('brochure');
			return $query->result();
		}

		public function delete_data($id){
			$this->db->where("id", $id);  
           $this->db->delete("brochure");
           return true;  
           //DELETE FROM tbl_user WHERE id = $id 
		}

		



		//note uploade
		function uplode_note($data)
		{
			$this->db->insert('notes',$data);
			return true;		
		}

		//get nots

		public function notes_get(){

			$this->db->order_by('id','desc');
			$query = $this->db->get('notes');
			return $query->result();
		}

		//delete notes

		public function delete_notes($id){
			$this->db->where("id",$id);
			$this->db->delete('notes');
			return true;
		}


		//student
		function student($data)
		{
			$this->db->insert('student',$data);
			return true;		
		}

		//get_student 

		public function get_student(){

			$this->db->order_by('id','desc');
			$query = $this->db->get('student');
			return $query->result();
		}
		//delete student

		public function delete_student($id){
			$this->db->where("id",$id);
			$this->db->delete('student');
			return true;
		}

		//register_search

		public function register_search($name,$number){
			
			 $this->db->like('name', $name);
             $this->db->like('number', $number);
             $result = $this->db->get('enquiry');

    		return $result->result();
		}

		//certified_note

		public function certified_note($data){
			$this->db->insert('certified_note',$data);
			return true;
		}

		//certificate_note_get

		public function certificate_note_get(){
             $query = $this->db->get('certified_note');
             return $query->result();
		}

		//important_details

		public function important_details($data){
			$this->db->insert('important_details',$data);
			return true;
		}


		//get_contact_details

		public function get_contact_details(){
			$query = $this->db->get('important_details');
			return $query->result();
		}
		
		//delete_contact
		
		public function delete_contact($id){
		    $this->db->where("id",$id);
			$this->db->delete('important_details');
			return true;
		    
		}

		//delete_note
		public function delete_note($id){
		    $this->db->where("id",$id);
			$this->db->delete('certified_note');
			return true;
		    
		}

		//get_view_batch

		public function get_view_batch(){
			$query = $this->db->get('batch');
			return $query->result();
		}

		//delete_batch

		public function delete_batch($id){
		    $this->db->where("id",$id);
			$this->db->delete('batch');
			return true;
		    
		}

		//get_view_feedback

		public function get_view_feedback(){
			$query = $this->db->get('feedback');
			return $query->result();
		}

		//delete_feedback


		public function delete_feedback($id){
		    $this->db->where("id",$id);
			$this->db->delete('feedback');
			return true;
		    
		}

		//get_view_placement

		public function get_view_placement(){
			$query = $this->db->get('placment_opening');
			return $query->result();
		}	

		//delete_placement

		public function delete_placement($id){
		    $this->db->where("id",$id);
			$this->db->delete('placment_opening');
			return true;
		    
		}

		//get_view_current_opening

		public function get_view_current_opening(){
			$query = $this->db->get('current_opening');
			return $query->result();
		}

        //delete_current_opening

        public function delete_current_opening($id){
		    $this->db->where("id",$id);
			$this->db->delete('current_opening');
			return true;
		    
		}

		//get_view_payment

		public function get_view_payment(){
			$query = $this->db->get('payfee');
			return $query->result();
		}

		//get_placment_line_up_remainder_date

		public function get_placment_line_up_remainder_date(){
			$this->db->where('interview_date',date('y-m-d'));
			$query = $this->db->get('placment_opening');
			return $query->result();
		}

		//register

		public function register($data){
			$this->db->insert('enquiry',$data);
			return true;
		}

		//delete_certificate_note

		 public function delete_certificate_note($id){
		    $this->db->where("id",$id);
			$this->db->delete('certified_note');
			return true;
		    
		}

		//get_view_registration

		public function get_view_registration(){
			$this->db->where('register_for','New Student');
			$query = $this->db->get('enquiry');
			return $query->result();
		}

		//update_register

		public function update_register($data,$id){

			$this->db->where('id',$id);
			$this->db->update('enquiry',$data);
			return true;
		}

		//delete_view_register

		public function delete_view_register($id){
			$this->db->where('id',$id);
			$this->db->delete('enquiry');
			return true;
		}
				
					


	

}
?>

