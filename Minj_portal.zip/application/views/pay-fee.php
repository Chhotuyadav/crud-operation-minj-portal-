<?php

	if( !isset($_SESSION['id_']) ){
		redirect(base_url(),'refresh');
		die();
	}
	?>
<div class="home-background">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 bar_">
				<a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" class=" rounded-3 p-1 text-decoration-none"><i class="bi bi-list bi-lg py-2 p-1"></i>⏪  ⏩</a>
				<?php include('include/sidebar.php') ?>
			</div>
			<div class="col-sm-9 home_">
				<h3>Pay Fee</h3>
				<form method="post"  class="form_">
				<div class="row mt-3 mb-3">
						<div class="col-sm-6">
							<label class="mb-2" for="name">StudentName/Batch ID</label>
							<input type="text" name="name_batch" class="form-control">
						</div>

						<div class="col-sm-6">
							<label class="mb-2" for="Course">Course</label>
							<input type="text" name="course" class="form-control">
						</div>
				</div>
					   <input type="submit" name="submit" value="Search" class="btn btn-primary mb-3 mt-3">
				</form>

				<div class="row">
					<div class="responsive mb-3">
						<table class="table table-hover table_">
					  <thead>
					    <tr>
					      <th scope="col">#</th>
					      <th scope="col">Name</th>
					      <th scope="col">Contact No.</th>
					      <th scope="col">Courses</th>
					      <th scope="col">Batch ID</th>
					      <th scope="col">Course Fee</th>
					      <th scope="col">Discount</th>
					      <th scope="col">Fee After Discount</th>
					      <th scope="col">PaidsoFar</th>
					      <th scope="col">First Installment</th>
					      <th scope="col">Secound Installment</th>
					      <th scope="col">Third Installment</th>
					      <th scope="col">Registration Date</th>
					      <th scope="col">Email ID</th>
					    </tr>
					  </thead>

					  <tbody>
					    <tr>
					      <th scope="row">1</th>
					      <td>Mark</td>
					      <td>Otto</td>
					      <td>@mdo</td>
					      <td>Mark</td>
					      <td>Otto</td>
					      <td>@mdo</td>
					      <td>Mark</td>
					      <td>Otto</td>
					      <td>@mdo</td>
					      <td>Mark</td>
					      <td>Otto</td>
					      <td>@mdo</td>
					      <td>@mdo</td>
					    </tr>

					  </tbody>
					</table>
					</div>
				</div>

				<form method="post" action="<?= base_url('data/payfee') ?>" class="form_">
				<div class="row">
					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Student Name:</label>	
				    	<input type="text" class="form-control " id="" name="student_name" >
					</div>

					<div class ="col-sm-4 mb-2">
					    <label for="exampleInputPassword1" class="form-label">Course Fee:</label>
				      	<input type="text" class="form-control" id="number" name="course_fee"  required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">BatchID:</label>	
				    	<input type="text" class="form-control " id="batch_id" name="batch_id" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Discount:</label>	
				    	<input type="text" class="form-control " id="discount" name="discount" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Installment  Date:</label>	
				    	<input type="date" class="form-control " id="instalation_date" name="instalation_date" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Fee After Discount:</label>	
				    	<input type="text" class="form-control " id="fee_after_discount" name="fee_after_discount" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Gender:</label>	<br>
				    	<input type="radio"  id="gender" name="gender" value="male"> <label for="male">Male</label>
                        <input type="radio"  id="gender" name="gender" value="female"> <label for="female">Female</label>
                        
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Remaining Amount:</label>	
				    	<input type="text" class="form-control " id="remaining-amount" name="remaining_amount" >
					</div>
					
					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Native Place:</label>	
				    	<input type="text" class="form-control " id="native_p_" name="native_p_" >
					</div>


					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Payment Mode:</label>	<br>
				    	<input type="radio"  id="" name="Payment_mode" value="Cash"> <label for="male">Cash</label>
                        <input type="radio"  id="" name="Payment_mode" value="Cheque" > <label for="female">Cheque</label>
                        
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Courses:</label>	
				    	<input type="text" class="form-control " id="course" name="course" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">	Paid So Far:</label>	
				    	<input type="text" class="form-control " id="paid_so_for" name="paid_so_for" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Contact No:</label>	
				    	<input type="text" class="form-control " id="contact_nu" name="contact_nu" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Due Amount:</label>	
				    	<input type="text" class="form-control " id="due_amount" name="due_amount" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Email ID:</label>	
				    	<input type="email" class="form-control " id="email_id" name="email_id" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">	Due Date:</label>	
				    	<input type="date" class="form-control " id="due_date" name="due_date" >
					</div>

					<input type="date" hidden  name="date" value="<?php echo date('y-m-d') ?>">

					<div class="col-sm-12 mb-2 mt-2 d-flex" >
						<input type="submit" name="save" value="Update" class="btn btn-primary ">
					</div>

				</div>
				</form>

			</div>
		</div>
	</div>
</div>
</body>
</html>
