<!DOCTYPE html>
<html>
<head>

  <title>Minj Education</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- css************************************************* -->

    <link rel="stylesheet" type="text/css" href="<?= base_url('css/style.css')?>">

    <!-- css************************************************* -->

    <!-- jquery cdn  ***************************** -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="<?= base_url('js/script.js') ?>"></script>

    <!-- jquery cdn  ***************************** -->

</head>

<body>

</body>
</html>

<nav class="navbar navbar-expand-lg navbar-light ">
  <div class="container">
    <a class="navbar-brand" href="<?= base_url(); ?>">
      <img src="<?= base_url('images/Minj_Logo.png')  ?>">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 menu">
        <li class="nav-item">
          <a class="nav-link active home" aria-current="page" href="<?= base_url('home'); ?>">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link enquery" href="<?= base_url('enquiry') ?>">Enquiry</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?= base_url('pay-fee') ?>">Pay Fee</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?= base_url('registration') ?>">Registration</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?= base_url('follow-up') ?>">Follow Up</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?= base_url('batch') ?>">Batch</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?= base_url('placement') ?>">Placement</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?= base_url('feedback') ?>">Feedback</a>
        </li>

        <li class="nav-item">
          <?php

          if( !isset($_SESSION['id_']) ){
          }
          else{?>
          <a class="nav-link" href="<?= base_url('data/logout') ?>">Logout</a>

          <?php }
          ?>
        </li>

        <li class="nav-item">
          <?php

          if( !isset($_SESSION['id_']) ){
          }
          else{?>
          <a class="nav-link" href="<?= base_url('change-password') ?>">Change Password</a> 
          <?php }
          ?>
        </li>

      </ul>
    </div>
  </div>
</nav>
