<div class="container-fluid">
    <div class="row flex-nowrap">
        <div class="col-auto px-0">
            <div id="sidebar" class="collapse collapse-horizontal show border-end">
                <h4 class="text-center mt-3">Hello Admin </h4>
                <div id="sidebar-nav" class="list-group border-0 rounded-0 text-sm-start min-vh-100">
                    <a href="<?= base_url('due-payment-remainder') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-bootstrap"></i> <span>Due Payment Remainder</span> </a>

                    <a href="<?= base_url('enquiry-follow-up') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-film"></i> <span>Enquiry Follow Up Remainder</span></a>

                    <a href="<?= base_url('placment-line-up-remainder') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-heart"></i> <span>Placement Line Up Remainder</span></a>

                    <a href="<?= base_url('certificate-note') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-bricks"></i> <span>Certificate/Note</span></a>

                    <a href="<?= base_url('contact-details') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-clock"></i> <span>Contact Details</span></a>

                   <!-- <a href="<?= base_url('add-courses') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-archive"></i> <span>Add Courses</span></a>

                    <a href="<?= base_url('add-university') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-gear"></i> <span>Add University</span></a>-->

                    <a href="<?= base_url('view-registration') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-calendar"></i> <span>View Registration</span></a>

                    <a href="<?= base_url('view-batched') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-calendar"></i> <span>View Batched</span></a>

                    <a href="<?= base_url('view-feedback') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-calendar"></i> <span>View Feedback</span></a>

                    <a href="<?= base_url('view-placement') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-calendar"></i> <span>View Placement</span></a>

                    <a href="<?= base_url('view-current-opening') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-calendar"></i> <span>View Current Opening</span></a>

                    <!--<a href="<?= base_url('view-important-contact') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-calendar"></i> <span>View Important Contact</span></a>-->

                    <!--<a href="<?= base_url('view-and-delete-status') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-calendar"></i> <span>View and Delete Status</span></a>-->

                    <a href="<?= base_url('view-payment') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-calendar"></i> <span>View Payment</span></a>

                    <a href="<?= base_url('upload-edit-delete-images') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-calendar"></i> <span>Upload/Edit/Delete Image</span></a>

                    <!-- <a href="<?= base_url('insert-update-delete-news') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-calendar"></i> <span>Inser/Update/Delete News</span></a> -->

                    <a href="<?= base_url('insert-update-delete-brochure') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-calendar"></i> <span>Inser/Update/Delete Brochure</span></a>

                    <a href="<?= base_url('update-note') ?>" class="list-group-item not_active border-end-0 d-inline-block text-truncate" data-bs-parent="#sidebar"><i class="bi bi-calendar"></i> <span>Update Note</span></a>

                </div>
            </div>
        </div>
    </div>
</div>



















