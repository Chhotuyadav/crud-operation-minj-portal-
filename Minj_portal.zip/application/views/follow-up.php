<?php

	if( !isset($_SESSION['id_']) ){
		redirect(base_url(),'refresh');
		die();
	}
	?>
<div class="home-background">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 bar_">
				<a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" class=" rounded-3 p-1 text-decoration-none"><i class="bi bi-list bi-lg py-2 p-1"></i>⏪  ⏩</a>
				<?php include('include/sidebar.php') ?>
			</div>
			<div class="col-sm-9 home_">
				<h3>Follow Up</h3>
				<form class="form_" method="post" action="<?= base_url('data/fellow_up')?>">
				<div class="row mt-3 mb-3">
						<div class="col-sm-6">
							<label class="mb-2" for="name">StudentName:</label>
							<input type="text" name="student_name" required class="form-control" placeholder="Enter Student Name">
						</div>

						<div class="col-sm-6">
							<label class="mb-2"  for="student_status">Student Status</label>
								<select name="student_status" class="form-control" required>
								<option >Select</option>
								<option value="Follow Up On">Follow Up On</option>
								<option value="Interested">Interested</option>
								<option value="Not interested">Not interested</option>
								<option value="Out Off Station">Out Off Station</option>
								<option value="Registred">Registred</option>
								<option value="Scholarship Valid till">Scholarship Valid till</option>
								<option value="Switch of Phone">Switch of Phone</option>
								<option value="Will Call On">Will Call On</option>
								<option value="Will Visit On">Will Visit On</option>

							</select>
						</div>

						<div class="col-sm-6">
							<label class="mb-2" for="select_course">Select Course</label>
								<select name="select_course" required class="form-control">
								<option >Select Courses</option>
								<option value="MCI-DotNet">MCI-DotNet</option>
								<option value="MCI- CORE JAVA">MCI- CORE JAVA</option>
								<option value="MCI-ADCA">MCI-ADCA</option>
								<option value="MCI-MONTHLY">MCI-MONTHLY</option>
								<option value="MGU-DCAP">MGU-DCAP</option>
								<option value="MCI-DHN">MCI-DHN</option>
								<option value="MCI-TALLY">MCI-TALLY</option>
								<option value="MCI-ADVANCE EXCEL">MCI-ADVANCE EXCEL</option>
								<option value="MCI-DCA">MCI-DCA</option>
								<option value="MCI-ADCA">MCI-ADCA</option>
								<option value="MCI-PGDCA">MCI-PGDCA</option>
								<option value="MCI-PGDCAP">MCI-PGDCAP</option>
								<option value="MCI-JAS-CCA">MCI-JAS-CCA</option>
								<option value="MCI-DTP">MCI-DTP</option>
								<option value="MCI-INTERNET">MCI-INTERNET</option>
								<option value="MCI-PROGRAMMING">MCI-PROGRAMMING</option>
								<option value="SVU-PGDCA">SVU-PGDCA</option>
								<option value="MCI-JAS-DHN">MCI-JAS-DHN</option>
								<option value="SHRIDHAR U ( M.B.A.)">SHRIDHAR U ( M.B.A.)</option>
								<option value="SHRIDHAR U M.B.A.(Exicutive)">SHRIDHAR U M.B.A.(Exicutive)</option>
								<option value="Tally 30 Interview Question">Tally 30 Interview Question</option>
								<option value="Tally ERP Short Cut Key">Tally ERP Short Cut Key</option>
								<option value="MCI-DCA &amp; DTP">MCI-DCA &amp; DTP</option>
								<option value="MCI-ADFA">MCI-ADFA</option>
								<option value="MCI-PGDCPA">MCI-PGDCPA</option>
								<option value="MCI-DOA">MCI-DOA</option>
								<option value="MCI-DFA">MCI-DFA</option>
								<option value="MCI-JAS-CDTP">MCI-JAS-CDTP</option>
								<option value="MCI-CCA">MCI-CCA</option>
								<option value="MCI-DCAP">MCI-DCAP</option>
								<option value="MCI-DGDA">MCI-DGDA</option>
								<option value="MGU-PGDCA-P">MGU-PGDCA-P</option>
								<option value="MCRV-DCA">MCRV-DCA</option>
								<option value="GOU-DCA">GOU-DCA</option>
								<option value="GOU-ADCA">GOU-ADCA</option>
								<option value="GOU-PGDCA">GOU-PGDCA</option>
								<option value="GOU-ADFA">GOU-ADFA</option>
								<option value="GOU-DOA">GOU-DOA</option>
								<option value="GOU-DFA">GOU-DFA</option>
								<option value="GOU-DHN">GOU-DHN</option>
								<option value="MCI-C">MCI-C</option>
								<option value="MCI-C++">MCI-C++</option>
								<option value="MCI-C&amp;C++">MCI-C&amp;C++</option>
								<option value="MCI-CORE JAVA">MCI-CORE JAVA</option>
								<option value="MCI-ADVANCED JAVA">MCI-ADVANCED JAVA</option>
								<option value="MCI-ANDORID">MCI-ANDORID</option>
								<option value="MCI-HTML">MCI-HTML</option>
								<option value="MCI-PHP">MCI-PHP</option>
								<option value="MCI-CSS+JAVA SCRIPT">MCI-CSS+JAVA SCRIPT</option>
								<option value="MCI-HTML+CSS+JS+PROJECT">MCI-HTML+CSS+JS+PROJECT</option>
								<option value="MCI-SEO ON LIVE PROJECT">MCI-SEO ON LIVE PROJECT</option>
								<option value="SVU M.P.-(B.A,B.SC,B.COM(PLAIN)">SVU M.P.-(B.A,B.SC,B.COM(PLAIN)</option>
								<option value="SVU M.P.-(M.B.A)">SVU M.P.-(M.B.A)</option>
								<option value="SVU M.P.-(M.B.A) -EXECUTIVE">SVU M.P.-(M.B.A) -EXECUTIVE</option>
								<option value="SVU M.P.-(M.A,M.SC,B.COM(PLAIN)">SVU M.P.-(M.A,M.SC,B.COM(PLAIN)</option>
								<option value="SVU M.P.-(M.A,M.SC,B.COM(SPEC.)">SVU M.P.-(M.A,M.SC,B.COM(SPEC.)</option>
								<option value="SVU M.P.-(M.C.A,B.B.A,B.C.A)">SVU M.P.-(M.C.A,B.B.A,B.C.A)</option>
								<option value="SVU M.P.-(B.TECH)">SVU M.P.-(B.TECH)</option>
								<option value="SVU M.P.-(M.TECH)">SVU M.P.-(M.TECH)</option>
								<option value="SVU M.P.-(POLY DIPLOMA)">SVU M.P.-(POLY DIPLOMA)</option>
								<option value="SVU M.P.-(P.HD)">SVU M.P.-(P.HD)</option>
								<option value="SVU M.P.-(DIPLOMA,PG DIPLOMA)">SVU M.P.-(DIPLOMA,PG DIPLOMA)</option>
								<option value="SVU M.P.-(DIPLOMA,PG DIPLOMA)">SVU M.P.-(DIPLOMA,PG DIPLOMA)</option>
								<option value="SHRIDAR U(M.A,M.SC,B.COM(PLAIN)">SHRIDAR U(M.A,M.SC,B.COM(PLAIN)</option>
								<option value="SHRIDAR U(M.A,M.SC,B.COM(SPEC.)">SHRIDAR U(M.A,M.SC,B.COM(SPEC.)</option>
								<option value="SHRIDAR U(B.TECH)">SHRIDAR U(B.TECH)</option>
								<option value="SHRIDAR U(M.TECH)">SHRIDAR U(M.TECH)</option>
								<option value="SHRIDAR U(POLY DIPLOMA)">SHRIDAR U(POLY DIPLOMA)</option>
								<option value="SHRIDAR U(DIPLOMA,PG DIPLOMA)">SHRIDAR U(DIPLOMA,PG DIPLOMA)</option>
								<option value="J.N.U. ( B.A, B.SC, B.COM(PLAIN )">J.N.U. ( B.A, B.SC, B.COM(PLAIN )</option>
								<option value="J.N.U.( B.A, B.SC, B.COM (SPEC)">J.N.U.( B.A, B.SC, B.COM (SPEC)</option>
								<option value="J.N.U.(M.B.A, ITI )">J.N.U.(M.B.A, ITI )</option>
								<option value="J.N.U.(M.B.A(EXICUTIVE)">J.N.U.(M.B.A(EXICUTIVE)</option>
								<option value="J.N.U.(M.A.,M.SC,B.COM(PLAIN)">J.N.U.(M.A.,M.SC,B.COM(PLAIN)</option>
								<option value="J.N.U.M.A,M.SC,B.COM(SPEC)">J.N.U.M.A,M.SC,B.COM(SPEC)</option>
								<option value="J.N.U.(M.C.A,B.B.A.,B.C.A)">J.N.U.(M.C.A,B.B.A.,B.C.A)</option>
								<option value="JO.N.U.(B.A.,B.SC,B.COM(PLAIN)">JO.N.U.(B.A.,B.SC,B.COM(PLAIN)</option>
								<option value="JO.N.U.(B.A.,B.SC,B.COM(SPEC">JO.N.U.(B.A.,B.SC,B.COM(SPEC</option>
								<option value="JO.N.U.(M.B.A)">JO.N.U.(M.B.A)</option>
								<option value="JO.N.U.(M.B.A(EXICUTIVE)">JO.N.U.(M.B.A(EXICUTIVE)</option>
								<option value="JO.N.U.(M.A,M.SC,B.COM(PLAIN)">JO.N.U.(M.A,M.SC,B.COM(PLAIN)</option>
								<option value="JO.N.U.(B.A.,B.SC,B.COM(SPEC">JO.N.U.(B.A.,B.SC,B.COM(SPEC</option>
								<option value="JO.N.U.(POLY TECHNIQUE DIPLOMA)">JO.N.U.(POLY TECHNIQUE DIPLOMA)</option>
								<option value="JO.N.U.(M.C.A,B.B.A.,B.C.A)">JO.N.U.(M.C.A,B.B.A.,B.C.A)</option>
								<option value="JO.N.U.(P.HD)">JO.N.U.(P.HD)</option>
								<option value="JO.N.U.(DIPLOMA,PG DIPLOMA)">JO.N.U.(DIPLOMA,PG DIPLOMA)</option>
								<option value="C.V.R.U (B.A,B.SC.B.COM(PLAIN)">C.V.R.U (B.A,B.SC.B.COM(PLAIN)</option>
								<option value="C.V.R.U (B.A,B.SC,B.COM(SPEC)">C.V.R.U (B.A,B.SC,B.COM(SPEC)</option>
								<option value="C.V.R.U (M.B.A)">C.V.R.U (M.B.A)</option>
								<option value="C.V.R.U (M.A,M.SC,B.COM(SPEC)">C.V.R.U (M.A,M.SC,B.COM(SPEC)</option>
								<option value="M.M.Y.J U (B.A,B.SC,B.COM(PLAIN)">M.M.Y.J U (B.A,B.SC,B.COM(PLAIN)</option>
								<option value="M.M.Y.J U (B.A,B.SC,B.COM(SPEC)">M.M.Y.J U (B.A,B.SC,B.COM(SPEC)</option>
								<option value="M.M.Y.J U (M.B.A)">M.M.Y.J U (M.B.A)</option>
								<option value="M.M.Y.J U (M.B.A( EXICUTIVE)">M.M.Y.J U (M.B.A( EXICUTIVE)</option>
								<option value="M.M.Y.J U (M.A,M.SC,B.COM(PLAIN)">M.M.Y.J U (M.A,M.SC,B.COM(PLAIN)</option>
								<option value="M.M.Y.J U (M.A,M.SC,B.COM(SPEC)">M.M.Y.J U (M.A,M.SC,B.COM(SPEC)</option>
								<option value="M.M.Y.J U (M.C.A,B.B.A.,B.C.A)">M.M.Y.J U (M.C.A,B.B.A.,B.C.A)</option>
								<option value="S.U.UP(B.A,B.SC,B.COM(PLAIN)">S.U.UP(B.A,B.SC,B.COM(PLAIN)</option>
								<option value="S.U.UP(B.A,B.SC,B.COM(SPEC)">S.U.UP(B.A,B.SC,B.COM(SPEC)</option>
								<option value="S.U.UP(M.B.A.)">S.U.UP(M.B.A.)</option>
								<option value="S.U.UP(M.A,M.SC,B.COM(PLAIN)">S.U.UP(M.A,M.SC,B.COM(PLAIN)</option>
								<option value="S.U.UP(M.A,M.SC,B.COM(SPEC)">S.U.UP(M.A,M.SC,B.COM(SPEC)</option>
								<option value="MCU-DCA">MCU-DCA</option>
								<option value="ITRC-ADCA">ITRC-ADCA</option>
								<option value="MCI-FULL COURSES">MCI-FULL COURSES</option>
								<option value="SVU-FULL COURSES">SVU-FULL COURSES</option>
								<option value="ITRC-FULL COURSES">ITRC-FULL COURSES</option>
								<option value="ITRC-ADFA">ITRC-ADFA</option>
								<option value="J.N.U. ( ITI Regular )">J.N.U. ( ITI Regular )</option>
								<option value="UG-DEGREE ">UG-DEGREE </option>
								<option value="PG-DEGREE">PG-DEGREE</option>
								<option value="D.ED,B.ED,MBA">D.ED,B.ED,MBA</option>
								<option value="MGU-PGDCAP">MGU-PGDCAP</option>
								<option value="NSDC">NSDC</option>
								<option value="10th Class">10th Class</option>
								<option value="12th class">12th class</option>
								<option value="Advance Tally V1+V2">Advance Tally V1+V2</option>
								<option value="MCI-JAS-CPCA">MCI-JAS-CPCA</option>
								<option value="MCI-JAS-CCA">MCI-JAS-CCA</option>
								<option value="MCI-AD EXCEL">MCI-AD EXCEL</option>
								<option value="Powerpoint">Powerpoint</option>
								<option value="Coral Draw">Coral Draw</option>
								<option value="Photoshop">Photoshop</option>
								<option value="Photoshop">Photoshop</option>
								<option value="Hindi Typing">Hindi Typing</option>
								<option value="Computer Typing">Computer Typing</option>
								<option value="Computer Repair">Computer Repair</option>
								<option value="Computer Purchase">Computer Purchase</option>
								<option value="Computer Sales">Computer Sales</option>
								<option value="MAKHANLAL UNIVERSITY">MAKHANLAL UNIVERSITY</option>
								<option value="PLACEMENT">PLACEMENT</option>
								<option value="MINJ-JAS-CBCA">MINJ-JAS-CBCA</option>
								<option value="MCI-TALLY-1">MCI-TALLY-1</option>
								<option value="D.Ed">D.Ed</option>
								<option value="B.Ed">B.Ed</option>
								<option value="MCI-Syllabus">MCI-Syllabus</option>
								<option value="Shortcut Key">Shortcut Key</option>
								<option value="Data Entry Work">Data Entry Work</option>
								<option value="Computer Complain Repair">Computer Complain Repair</option>
								<option value="Computer Fundamental">Computer Fundamental</option>
								<option value="MCI-DOA">MCI-DOA</option>
								<option value="TALLY">TALLY</option>
								<option value="Virus History">Virus History</option>
								<option value="Virus History">Virus History</option>
								<option value="TALLY NOTES">TALLY NOTES</option>
								<option value="MCI-COA">MCI-COA</option>
								<option value="Tally Ledgers">Tally Ledgers</option>
							</select>
						</div>

						<div class="col-sm-6">
							<label class="mb-2" for="remark">Remark:</label>
							<input type="text" name="remark" class="form-control" placeholder="Enter Remark" required>
						</div>

						<input type="date" hidden name="date" value="<?php echo date('Y-m-d'); ?>">
				</div>
					   <input type="submit" name="save" value="Submit" class="btn btn-primary mb-3 mt-3">
				</form>
			</div>
		</div>
	</div>
</div>
</body>
</html>


