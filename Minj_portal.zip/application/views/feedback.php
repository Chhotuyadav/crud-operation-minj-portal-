<?php

	if( !isset($_SESSION['id_']) ){
		redirect(base_url(),'refresh');
		die();
	}
	?>
<div class="home-background">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 bar_">
				<a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" class=" rounded-3 p-1 text-decoration-none"><i class="bi bi-list bi-lg py-2 p-1"></i>⏪  ⏩</a>
				<?php include('include/sidebar.php') ?>
			</div>
			<div class="col-sm-9 home_">
				<h3>Feedback</h3>

				<form class="form_" method="post" action="<?= base_url('data/feedback')  ?>">
				<div class="row mt-3 mb-3">
					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Student Name">Student Name:</label>
						<input type="text" name="student_name" class="form-control">
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Mobile Contact">Mobile/Contact No:</label>
						<input type="text" name="contact_number" class="form-control">
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="If Interested in any further Course">If Interested in any further Course:</label>
						<input type="text" name="if_intrested_in_any" class="form-control">
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Desire Profile">Desire Profile:</label>
							<select name="desire_profile" class="form-control">
								<option>Select</option>
								<option value="Sir">Sir</option>
			                	<option value="Close Friends">Close Friends</option>
			                	<option value="Madam">Madam</option>
			                	<option value="Marketing">Marketing</option>
			                	<option value="Doctors">Doctors</option>
			                	<option value="Others">Others</option>
			                	<option value="Software Company">Software Company</option>
			                	<option value="Counsellor">Counsellor</option>
			                	<option value="Stock ">Stock </option>
			                	<option value="UID Work">UID Work</option>
							</select>
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Refernces if any">Refernces if any Name:</label>
						<input type="text" name="refernces_if_any_name" class="form-control" placeholder="Name">
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Refernces if any">Refernces if any Contact:</label>
						<input type="text" name="refernces_if_any_contact" class="form-control" placeholder="Contact">
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Duration">Trading account with Minj:</label><br>
						<input type="radio" name="trading_yesno" value="YES"><label for="YES">&nbsp;YES</label>
						<input type="radio" name="trading_yesno" value="No"><label for="No">&nbsp;No</label>
					</div>

				</div>
					 <input type="submit" name="save" value="Submit" class="btn btn-primary mb-3 mt-3">
				</form>
			</div>
		</div>
	</div>
</div>
</body>
</html>