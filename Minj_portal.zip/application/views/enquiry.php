<?php

	if( !isset($_SESSION['id_']) ){
		redirect(base_url(),'refresh');
		die();
	}
	?>
<div class="home-background">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 bar_">
				<a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" class=" rounded-3 p-1 text-decoration-none"><i class="bi bi-list bi-lg py-2 p-1"></i>⏪  ⏩</a>
				<?php include('include/sidebar.php') ?>
			</div>
			<div class="col-sm-9 home_">
				<h3>Enquiry</h3>
				<form method="post" action="<?= base_url() ?>data/savedata" class="form_">
				<div class="row">
					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Name:</label>	
				    	<input type="text" class="form-control " id="name" name="name" required>
					</div>

					<div class ="col-sm-4 mb-2">
					    <label for="exampleInputPassword1" class="form-label">Contact No.:</label>
				      	<input type="text" class="form-control" id="number" name="number" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Father's Name:</label>	
				    	<input type="text" class="form-control " id="f_name" name="f_name" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Mother's Name:</label>	
				    	<input type="text" class="form-control " id="m_name" name="m_name" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Date of Birth:</label>	
				    	<input type="date" class="form-control " id="dob" name="dob" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Gender:</label>	<br>
				    	<input type="radio"  id="gender" name="gender" value="male"> <label for="male">Male</labelrequired>
                        <input type="radio"  id="gender" name="gender" value="female"> <label for="female">Female</labelrequired>
                        
					</div>

					<div class ="col-sm-4 mb-2">
					  <label for="exampleInputEmail1" class="form-label">Category:</label>	<br>
				    	
				    	<select class="form-control " id="category" name="category">
                              <option >Select Category</option>
                              <option value="General">General</option>
                              <option value="OBC">OBC</option>
                              <option value="SC">SC</option>
                              <option value="ST">ST</option>
                      </select>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Education Qualification:</label>	
				    	<input type="text" class="form-control " id="qualification" name="qualification" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Email ID:</label>	
				    	<input type="text" class="form-control " id="email" name="email" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Native Place:</label>	
				    	<input type="text" class="form-control " id="native_p" name="native_p" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Enquiry Date:</label>	
				    	<input type="date" class="form-control " id="enquiry_d" name="enquiry_d" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Reference:</label>	
				    	<input type="text" class="form-control " id="reference" name="reference" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Pref. of Time:</label>	
				    	<input type="text" class="form-control " id="pr_time" name="pr_time" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Expected DOJ:</label>	
				    	<input type="text" class="form-control " id="doj" name="doj" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Right Now:</label>	
				    	<input type="text" class="form-control " id="right_now" name="right_now" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Select Courses:</label>	
				    	<input type="text" class="form-control " id="courses" name="courses" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Enquiry Through:</label>	
				    	<input type="text" class="form-control " id="enquiry_t" name="enquiry_t" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Follow Up Date:</label>	
				    	<input type="date" class="form-control " id="follow_d" name="follow_d" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Course Fee:</label>	
				    	<input type="text" class="form-control " id="course_fee" name="course_fee" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Select University:</label>	
				    	<input type="text" class="form-control " id="university" name="university" required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Remark:</label>	
				    	<input type="text" class="form-control " id="remark" name="remark" required>
					</div>

                    <div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Purpose of Enquiry:</label>	
				    	<input type="text" class="form-control " id="purpose_e" name="purpose_e" required>
					</div>

					<input type="date" hidden name="date"  value="<?php echo date('Y-m-d'); ?>">

					<div class="col-sm-12 mb-2 mt-2 d-flex" >
						<input type="submit" name="save" class="btn btn-primary "required>
					</div>

				</div>
				</form>

			</div>
		</div>
	</div>
</div>
</body>
</html>
