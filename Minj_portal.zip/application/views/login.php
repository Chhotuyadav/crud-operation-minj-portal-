<?php
  if( isset($_SESSION['id_']) ){
    redirect('home','refresh');
  
  }
  else{

  ?>
<style type="text/css">	.navbar { display: none; }</style>
<div class="login">
  <div class="col-sm-4 offset-sm-4 login-form">
    <div class="row">
      <h3>Admin Panel Login</h3>
        <form method="post" action="<?php echo base_url('data/login_user'); ?>">
          <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label"><b>Email :</b> </label>
            <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" required>
          </div>
          <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label"><b>Password :</b></label>
            <input type="password" class="form-control" name="password" id="Password" placeholder="Enter Password" required>
          </div>
          <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1"><b>Remeber me</b></label>
          </div>
          <button type="submit" class="btn btn-primary" name="login">Login</button>
      </form>
      <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">⍰ Forgot password </a>
    </div>
  </div>
</div>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Forgot Password</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="post" action="<?= base_url('data/forgot_pass') ?>">
          <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label"><b>Registered Email :</b> </label>
            <input type="email" class="form-control" id="email_forgote" name="email_forgote" placeholder="Enter Email address" required>
          </div>
        
      </div>
      <div class="modal-footer">
        <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> -->
        <button type="submit" name="save" class="btn btn-primary">Reset Password</button>
      </div>
      </form>
    </div>
  </div>
</div>

</body>
</html>
<?php } ?>