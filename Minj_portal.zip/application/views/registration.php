<?php

	if( !isset($_SESSION['id_']) ){
		redirect(base_url(),'refresh');
		die();
	}
	?>
<div class="home-background">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 bar_">
				<a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" class=" rounded-3 p-1 text-decoration-none"><i class="bi bi-list bi-lg py-2 p-1"></i>⏪  ⏩</a>
				<?php include('include/sidebar.php') ?>
			</div>
			<div class="col-sm-9 home_">
				<h3>Registration</h3>
				<form class="form_" method="post" action="<?php echo base_url('welcome/search_student')?>">
				<div class="row mt-3 mb-3">
						<div class="col-sm-6">
							<label class="mb-2" for="name">StudentName</label>
							<input type="text" name="name" class="form-control">
						</div>

						<div class="col-sm-6">
							<label class="mb-2" for="contact">Contact Number</label>
							<input type="text" name="number" class="form-control">
						</div>
				</div>
					   <input type="submit" name="save" value="Search" class="btn btn-primary mb-3 mt-3">
				</form>

				


				<form method="post" action="<?= base_url('data/register') ?>" enctype="multipart/form-data" class="form_">
				<div class="row">

					<div class="col-sm-12">
				    	<input type="radio" name="register_for" class="stu_" value="Enquiry Student"><label class="label_" for="Enquiry Student"> Enquiry Student</label>
                        <input type="radio" name="register_for" class="stu" value="New Student"> <label class="label_" for="New Student"> New Student</label>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Student Name:</label>	
				    	<input type="text" class="form-control " id="" name="student_name" >
					</div>

					<div class ="col-sm-4 mb-2">
					    <label for="exampleInputPassword1" class="form-label">Contact No:</label>
				      	<input type="tel" class="form-control" id="contact" name="contact_nu"  required>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Father's Name:</label>	
				    	<input type="text" class="form-control " id="father_name" name="father_name" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">	Mother's Name:</label>	
				    	<input type="text" class="form-control " id="mother_name" name="mother_name" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Date Of Birth:</label>	
				    	<input type="date" class="form-control " id="dob" name="dob" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Gender:</label>	<br>
				    	<input type="radio"  id="gender" name="gender" value="male"> <label for="male">Male</label>
                        <input type="radio"  id="gender" name="gender" value="female"> <label for="female">Female</label>
                        
					</div>

					<div class="col-sm-4 mb-2" >
						<label for="Category">Category:</label>
						<select name="category" class="form-control">
							<option>Select Category</option>
							<option value="General">General</option>
							<option value="OBC">OBC</option>
							<option value="SC">SC</option>
							<option value="ST">ST</option>
							<option value="Other">Other</option>
						</select>
					</div>

					<div class="col-sm-4 mb-2" >
						<label for="education">Qualification:</label>
						<select name="education" class="form-control">
		                    <option >Select Qualification</option>
		                    <option value="5 Th">5 Th</option>
		                    <option value="8 Th">8 Th</option>
		                    <option value="10 Th">10 Th</option>
		                    <option value="12 Th">12 Th</option>
		                    <option value="Diploma">Diploma</option>
		                    <option value="Graduate">Graduate</option>
		                    <option value="Post Graduate">Post Graduate</option>
		                    <option value="Others Qualification">Others Qualification</option>
		                </select>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">E-Mail Id:</label>	
				    	<input type="email" class="form-control " id="email_id" name="email_id" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Native Place:</label>	
				    	<input type="text" class="form-control " id="native_p_" name="native_p_" >
					</div>
					
					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Courses:</label>	
				    	<input type="text" class="form-control " id="course" name="course" >
					</div>


					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Reference:</label>	
				    	<input type="text" class="form-control " id="refrence" name="refrence" >
					</div>

					<div class="col-sm-4 mb-2" >
						<label for="univercity">Univercity:</label>
						<select name="univercity" class="form-control">
		                    <option >Select Univercity</option>
		                </select>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">	Expected DOJ:</label>	
				    	<input type="text" class="form-control " id="expected_date" name="expected_date" >
					</div>

					<div class="col-sm-4 mb-2" >
						<label for="payment-mode">Payment Mode:</label>
						<select name="payment_mode" class="form-control">
		                    <option >Select Payment Mode</option>
		                    <option value="Full Payment" >Full Payment</option>
		                    <option value="First Installment">First Installment</option>
		                </select>
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Fee After Discount:</label>	
				    	<input type="text" class="form-control " id="fee_after_discount" name="fee_after_discount" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Course Fee:</label>	
				    	<input type="text" class="form-control " id="course_fee" name="course_fee" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">	Paid So Far:</label>	
				    	<input type="text" class="form-control " id="paid_so_for" name="paid_so_for" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">	Discount%:</label>	
				    	<input type="text" class="form-control " id="discount_per" name="discount_per" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">	Due Amount:</label>	
				    	<input type="text" class="form-control " id="due_amount" name="due_amount" >
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Working:</label>	<br>
				    	<input type="radio"  id="working" name="working" value="Yes"> <label for="male">Yes</label>
                        <input type="radio"  id="Wwrking" name="working" value="No"> <label for="female">No</label>
                        
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">	Due Date:</label>	
				    	<input type="date" class="form-control " id="due_date" name="due_date" >
					</div>

					<div class="col-sm-4 mb-2" >
						<label for="payment-mode">Right Now:</label>
						<input type="text" name="right_now" class="form-control">
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">Received Notes:</label>	<br>
				    	<input type="radio"  id="received_node" name="received_node" value="Yes"> <label for="yes">Yes</label>
                        <input type="radio"  id="received_node" name="received_node" value="No"> <label for="no">No</label>
                        
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">	Pref. Of Time:</label>	
				    	<input type="text" class="form-control " id="pref_of_time" name="pref_of_time" >
					</div> 

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">CDS:</label>	<br>
				    	<input type="radio"  id="CDS" name="CDS" value="Yes"> <label for="yes">Yes</label>
                        <input type="radio"  id="CDS" name="CDS" value="No"> <label for="no">No</label>
                        
					</div>

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">	Registration Date:</label>	
				    	<input type="date" class="form-control " id="registration_date" name="registration_date" >
					</div> 

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">	Remark:</label>	
				    	<input type="text" class="form-control " id="remark" name="remark" >
					</div> 

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">	Courses End On Date:</label>	
				    	<input type="date" class="form-control " id="course_end_on_date" name="course_end_on_date" >
					</div> 

					<div class ="col-sm-4 mb-2">
					<label for="exampleInputEmail1" class="form-label">	Upload Image:</label>	
				    	<input type="file" class="form-control " id="image" name="image_register" >
					</div> 

					<input type="text" hidden name="date" value="<?php echo date('y-m-d') ?>">

					<div class="col-sm-12 mb-2 mt-2 d-flex" >
						<input type="submit" name="save" value="Submit" class="btn btn-primary ">
					</div>

				</div>
				</form>

			</div>
		</div>
	</div>
</div>
</body>
</html>


