<?php

	if( !isset($_SESSION['id_']) ){
		redirect(base_url(),'refresh');
		die();
	}
	?>
<div class="home-background">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 bar_">
				<a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" class=" rounded-3 p-1 text-decoration-none"><i class="bi bi-list bi-lg py-2 p-1"></i>⏪  ⏩</a>
				<?php $this->load->view('include/sidebar.php');?> 
			</div>
			<div class="col-sm-9 home_">
				<h3>Due Payment Remainder</h3>
				<div style="overflow-x: auto;" class="row admin_">
					<table width="600" border="0" cellspacing="5" cellpadding="5">
					  <tr style="background:#CCC">
					    <th>Sr No</th>
					    <th>Student Name</th>
					    <th>Course Fee</th>
					    <th>Batch id</th>
					    <th>Discount</th>
					    <th>Instalation Date</th>
					    <th>Fee After Discount</th>
					  </tr>
					  <?php
					  $i=1;
					  foreach($data as $row)
					  {
					  echo "<tr>";
					  echo "<td>".$i."</td>";
					  echo "<td>".$row->student_name."</td>";
					  echo "<td>".$row->course_fee."</td>";
					  echo "<td>".$row->batch_id."</td>";
					  echo "<td>".$row->discount."</td>";
					  echo "<td>".$row->instalation_date."</td>";
					  echo "<td>".$row->fee_after_discount."</td>";
					  echo "</tr>";
					  $i++;
					  }
					   ?>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>
