<?php

	if( !isset($_SESSION['id_']) ){
		redirect(base_url(),'refresh');
		die();
	}
	?><div class="home-background">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 bar_">
				<a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" class=" rounded-3 p-1 text-decoration-none"><i class="bi bi-list bi-lg py-2 p-1"></i>⏪  ⏩</a>
				<?php $this->load->view('include/sidebar.php');?> 
			</div>
			<div class="col-sm-9 home_">
				<h3>Certificate Note</h3>
				<div >
					<form class="form_" method="post" action="<?= base_url('data/certified_note') ?>">
					
				<div class="row mt-3 mb-3">
					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Student Name">Student Name:</label>
						<input type="text" name="student_name" class="form-control">
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Contact No">Course Name:</label>
						<input type="text" name="course_name" class="form-control">
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Batch Time">Certificate No:</label>
						<input type="text" name="certificate_no" class="form-control">
					</div>

					
					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Selected">Result:</label><br>
						<input type="radio" name="Result"  value="Pass"><label for="Pass">&nbsp;Pass</label>
						<input type="radio" name="Result"  value="Fail"><label for="Fail">&nbsp;Fail</label>
					</div>
				

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Batch id">Date:</label>
						<input type="date" name="date" class="form-control">
					</div>
					

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Interview date">Remark:</label>
						<input type="text" name="remark" class="form-control">
					</div>

					
				</div>
					 <input type="submit" name="save" value="Submit" class="btn btn-primary mb-3 mt-3">
				</form>


				<div class="row admin_" style="overflow-x:auto;">
					 <?php
					/*echo "<pre>";
						print_r($data); */
					?> 


					<table width="600" border="0" cellspacing="5" cellpadding="5">
					  <tr style="background:#CCC">
					    <th>Sr No</th>
					    <th>Student Name</th>
					    <th>Course Name</th>
					    <th>Certificate No.</th>
					   	<th>Result</th>
					    <th>Date</th>
					    <th>Remark</th>
					    <th>Action</th>


					    	<?php
					   	$i=1;
					    foreach($data as $row){
					    ?>
						</tr>
						<tr>
						    <td><?php echo $i ?></td>
						    <td><?php echo $row->student_name ?></td>
						    <td><?php echo $row->course_name ?></td>
						    <td><?php echo $row->certificate_no ?></td>
						    <td><?php echo $row->Result ?></td>
						    <td><?php echo $row->date ?></td>
						    <td><?php echo $row->remark ?></td>
						    <td><button id="<?php echo $row->id ?>" class="btn btn-primary delete_data">Delete</button> </td>
						</tr>
					  <?php
					  $i++;
					  }
					   ?>
						
					</table>
				</div>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>
<script>  
      $(document).ready(function(){  
           $('.delete_data').click(function(){  
                var id = $(this).attr("id");  
                if(confirm("Are you sure you want to delete this?"))  
                {  
                     window.location="<?php echo base_url(); ?>Data/delete_certificate_note/"+id;  
                }  
                else  
                {  
                     return false;  
                }  
           });  
      });  
      </script> 