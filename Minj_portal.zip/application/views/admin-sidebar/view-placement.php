<?php

	if( !isset($_SESSION['id_']) ){
		redirect(base_url(),'refresh');
		die();
	}
	?>
<div class="home-background">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 bar_">
				<a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" class=" rounded-3 p-1 text-decoration-none"><i class="bi bi-list bi-lg py-2 p-1"></i>⏪  ⏩</a>
				<?php $this->load->view('include/sidebar.php');?> 
			</div>
			<div class="col-sm-9 home_">
				<h3>View Placement</h3>
				<div style="overflow-x: auto;" class="row admin_">
					<table  border="0" mt-3 cellspacing="5" cellpadding="5">
					  <tr style="background:#CCC">
					    <th>Sr No</th>
					    <th>Student Name</th>
					    <th>Contact No.</th>
					    <th>Selected Desired Profile:</th>
					   	<th>Selected Company Name</th>
					   	<th>Batch Id</th>
					   	<th>Interview Date</th>
					   	<th>Selected</th>
					    <th>Action</th>
					   	<?php
					   	$i=1;
					    foreach($data as $row){
					    ?>
						</tr>
						<tr>
						    <td><?php echo $i ?></td>
						    <td><?php echo $row->Student_name ?></td>
						    <td><?php echo $row->contact_no ?></td>
						    <td><?php echo $row->selected_desired_profile ?></td>
						    <td><?php echo $row->select_company_name ?></td>
						    <td><?php echo $row->batch_id ?></td>
						    <td><?php echo $row->interview_date  ?></td>
						    <td><?php echo $row->selected_yesno ?></td>
						    <td><button id="<?php echo $row->id ?>" class="btn btn-primary delete_data">Delete</button> </td>
						</tr>
					  <?php
					  $i++;
					  }
					   ?>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script>  
      $(document).ready(function(){  
           $('.delete_data').click(function(){  
                var id = $(this).attr("id");  
                if(confirm("Are you sure you want to delete this?"))  
                {  
                     window.location="<?php echo base_url(); ?>Data/delete_placement/"+id;  
                }  
                else  
                {  
                     return false;  
                }  
           });  
      });  
      </script> 