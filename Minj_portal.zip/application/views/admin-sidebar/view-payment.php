<?php

	if( !isset($_SESSION['id_']) ){
		redirect(base_url(),'refresh');
		die();
	}
	?>
<div class="home-background">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 bar_">
				<a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" class=" rounded-3 p-1 text-decoration-none"><i class="bi bi-list bi-lg py-2 p-1"></i>⏪  ⏩</a>
				<?php $this->load->view('include/sidebar.php');?> 
			</div>
			<div class="col-sm-9 home_">
				<h3>View Payment</h3>
				<div style="overflow-x: auto;" class="row admin_">
					<table  border="0" mt-3 cellspacing="5" cellpadding="5">
					  <tr style="background:#CCC">
					    <th>Sr No</th>
					    <th>Student Name</th>
					    <th>Course Fee</th>
					    <th>Batch ID</th>
					   	<th>Discount</th>
					   	<th>Installment Date</th>
					   	<th>Fee After Discount</th>
					   	<th>Gender</th>
					   	<th>details</th>
					    <th>Action</th> 
					    <?php
					   	$i=1;
					    foreach($data as $row){
					    ?>
						</tr>
						<tr>
						    <td><?php echo $i ?></td>
						    <td><?php echo $row->student_name ?></td>
						    <td><?php echo $row->course_fee ?></td>
						    <td><?php echo $row->batch_id ?></td>
						    <td><?php echo $row->discount ?></td>
						    <td><?php echo $row->instalation_date ?></td>
						    <td><?php echo $row->fee_after_discount  ?></td>
						    <td><?php echo $row->gender  ?></td>
						    <td><button class='btn btn-primary btn-sm'  data-bs-toggle='modal' data-bs-target='#model<?php echo $row->id ?>'>View More</button></td>
						    <td><button id="<?php echo $row->id ?>" class="btn btn-primary delete_data">Delete</button> </td>
								<div class="modal fade" id="model<?echo $row->id ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
								  <div class="modal-dialog">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title" id="exampleModalLabel">Payment Details</h5>
								        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
								      </div>
								      <div class="modal-body">
								      	<div class="row">   
									     <span class="col-sm-6 p-1"><b>Remaining Amount</b> : <?php echo $row->remaining_amount ?></span>
									     <span class="col-sm-6 p-1"><b>Native Place</b> : <?php echo $row->native_p_ ?></span>
									     <span class="col-sm-6 p-1"><b>payment Mode</b> : <?php echo $row->Payment_mode ?></span>
									     <span class="col-sm-6 p-1"><b>Course</b>: <?php echo $row->course ?></span>
									     <span class="col-sm-6 p-1"><b>Paid So far</b> : <?php echo $row->paid_so_for ?></span>
									     <span class="col-sm-6 p-1"><b>Contact No</b> : <?php echo $row->contact_nu ?></span>
									     <span class="col-sm-6 p-1"><b>Due Amount </b>: <?php echo $row->due_amount ?></span>
									     <span class="col-sm-6 p-1"><b> Email </b>: <?php echo $row->email_id ?></span>
									     <span class="col-sm-6 p-1"><b>Due Date</b>: <?php echo $row->due_date ?></span>
								        </div>
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
								      
								      </div>
								    </div>
								  </div>
								</div>
						</tr>
					  <?php
					  $i++;
					  }
					   ?>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>
