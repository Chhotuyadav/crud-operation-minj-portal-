<?php

	if( !isset($_SESSION['id_']) ){
		redirect(base_url(),'refresh');
		die();
	}
	?>
<div class="home-background">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 bar_">
				<a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" class=" rounded-3 p-1 text-decoration-none"><i class="bi bi-list bi-lg py-2 p-1"></i>⏪  ⏩</a>
				<?php $this->load->view('include/sidebar.php');?> 
			</div>
			<div class="col-sm-9 home_">
				<h3>Upload Edit Delete Images</h3>
				<div class="row admin_">
					<form method="post" action="<?= base_url('data/testiminials') ?>" enctype="multipart/form-data">
					<div class="row">

						<div class ="col-sm-6 mb-2">
						<label for="exampleInputEmail1" class="form-label">Select Student Image:</label>	
					    	<input type="file" class="form-control" id="student_image" name="student_image" required >
						</div>

						<div class="col-sm-12 mb-2 mt-2 d-flex" >
							<input type="submit" name="save" value="Update Brochure" class="btn btn-primary ">
						</div>

					</div>
					</form>

					<!-- view Image -->
				<hr class="mt-3 mb-3">
					<div style="overflow-x: auto;">
						<table class="center" width="600" border="0" cellspacing="5" cellpadding="5">
						  <tbody>
						  	<tr style="background:#CCC">
						    <th>Sr No.</th>
						    <th>Student Image</th>
						    <th>Action</th>
						  </tr>
						  <tr>
						  	<?php
						  	$i=1;
						  foreach($data as $row)
						  {
						  	echo "<tr>";
						  echo "<td>".$i."</td>";?>
						  <td class="brochure"><img src=" <?= base_url('uploads/student/').$row->student_image ?> "></td>
						  <?php
						  echo "<td><button id='$row->id' class='btn btn-primary delete_data'>Delete</button></td>";
						  echo "</tr>";
						  $i++;
						}
						  	?>
						  	
						  </tr>
						 </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script>  
      $(document).ready(function(){  
           $('.delete_data').click(function(){  
                var id = $(this).attr("id");  
                if(confirm("Are you sure you want to delete this?"))  
                {  
                     window.location="<?php echo base_url(); ?>Data/delete_student/"+id;  
                }  
                else  
                {  
                     return false;  
                }  
           });  
      });  
      </script> 