
<?php

	if( !isset($_SESSION['id_']) ){
		redirect(base_url(),'refresh');
		die();
	}
	?>
<div class="home-background">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 bar_">
				<a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" class=" rounded-3 p-1 text-decoration-none"><i class="bi bi-list bi-lg py-2 p-1"></i>⏪  ⏩</a>
				<?php $this->load->view('include/sidebar.php');?> 
			</div>
			<div class="col-sm-9 home_">
				<h3>View Current Opening</h3>
				<div style="overflow-x: auto;" class="row admin_">
					<table  border="0" mt-3 cellspacing="5" cellpadding="5">
					  <tr style="background:#CCC">
					    <th>Sr No</th>
					    <th>Company Name</th>
					    <th>Desired Profile</th>
					    <th>Date</th>
					   	<th>Action</th>
					   	<?php
					   	$i=1;
					    foreach($data as $row){
					    ?>
						</tr>
						<tr>
						    <td><?php echo $i ?></td>
						    <td><?php echo $row->company_name ?></td>
						    <td><?php echo $row->desired_profile ?></td>
						    <td><?php echo $row->date_ ?></td>
						    <td><button id="<?php echo $row->id ?>" class="btn btn-primary delete_data">Delete</button> </td>
						</tr>
					  <?php
					  $i++;
					  }
					   ?>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script>  
      $(document).ready(function(){  
           $('.delete_data').click(function(){  
                var id = $(this).attr("id");  
                if(confirm("Are you sure you want to delete this?"))  
                {  
                     window.location="<?php echo base_url(); ?>Data/delete_current_opening/"+id;  
                }  
                else  
                {  
                     return false;  
                }  
           });  
      });  
      </script> 