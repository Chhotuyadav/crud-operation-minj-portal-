<?php

	if( !isset($_SESSION['id_']) ){
		redirect(base_url(),'refresh');
		die();
	}
	?>
<div class="home-background">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 bar_">
				<a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" class=" rounded-3 p-1 text-decoration-none"><i class="bi bi-list bi-lg py-2 p-1"></i>⏪  ⏩</a>
				<?php $this->load->view('include/sidebar.php');?> 
			</div>
			<div class="col-sm-9 home_">
				<h3>Enquiry Follow Up</h3>
				<div class="row admin_" style="overflow-x:auto;">
					 <?php
					//echo "<pre>";
						/*print_r($data); */
					?> 


					<table width="600" border="0" cellspacing="5" cellpadding="5">
					  <tr style="background:#CCC">
					    <th>Sr No</th>
					    <th>First_name</th>
					    <th>Contact No.</th>
					    <th>DOB</th>
					   	<th>Qualification</th>
					    <th>Email</th>
					    <th>Details</th>
						</tr>
					  <?php
					  $i=1;
					  foreach($data as $row)
					  {
					  echo "<tr>";
					  echo "<td>".$i."</td>";
					  echo "<td>".$row->name."</td>";
					  echo "<td>".$row->number."</td>";
					  echo "<td>".$row->dob."</td>";
					  echo "<td>".$row->qualification."</td>";
					  echo "<td>".$row->email."</td>";
					  echo "<td><button class='btn btn-primary btn-sm'  data-bs-toggle='modal' data-bs-target='#model$row->id'>View More</button></td>";                   
					  echo "</tr>";
					  ?>
					  <!-- Modal -->
					<div class="modal fade" id="model<?echo $row->id ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
					  <div class="modal-dialog">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title" id="exampleModalLabel">Students Details</h5>
					        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					      </div>
					      <div class="modal-body">
					      	<div class="row">   
						     <span class="col-sm-6 p-1"><b>Name</b> : <?php echo $row->name ?></span>
						     <span class="col-sm-6 p-1"><b>Contact No.</b> : <?php echo $row->number ?></span>
						     <span class="col-sm-6 p-1"><b>Father's Name</b>: <?php echo $row->f_name ?></span>
						     <span class="col-sm-6 p-1"><b>Mother's Name</b> : <?php echo $row->m_name ?></span>
						     <span class="col-sm-6 p-1"><b>Date of Birth</b> : <?php echo $row->dob ?></span>
						     <span class="col-sm-6 p-1"><b>Gender </b>: <?php echo $row->gender ?></span>
						     <span class="col-sm-6 p-1"><b>Category </b>: <?php echo $row->category ?></span>
						     <span class="col-sm-6 p-1"><b>Education Qualification </b>: <?php echo $row->qualification ?></span>
						     <span class="col-sm-6 p-1"><b>Native Place </b>: <?php echo $row->native_p ?></span>
						     <span class="col-sm-6 p-1"><b>Enquiry Date </b>: <?php echo $row->enquiry_d ?></span>
						     <span class="col-sm-6 p-1"><b>Reference </b>: <?php echo $row->reference ?></span>
						     <span class="col-sm-6 p-1"><b>Pref. of Time </b>: <?php echo $row->pr_time ?></span>
						     <span class="col-sm-6 p-1"><b>Expected DOJ </b>: <?php echo $row->doj ?></span>
						     <span class="col-sm-6 p-1"><b>Right Now </b>: <?php echo $row->right_now ?></span>
						     <span class="col-sm-6 p-1"><b>Select Courses </b>: <?php echo $row->courses ?></span>
						     <span class="col-sm-6 p-1"><b>Enquiry Through </b>: <?php echo $row->enquiry_t ?></span>
						     <span class="col-sm-6 p-1"><b>Follow Up Date </b>: <?php echo $row->follow_d ?></span>
						     <span class="col-sm-6 p-1"><b>Course Fee </b>: <?php echo $row->course_fee ?></span>
						     <span class="col-sm-6 p-1"><b>Select University </b>: <?php echo $row->university ?></span>
						     <span class="col-sm-6 p-1"><b>Remark </b>: <?php echo $row->remark ?></span>
						     <span class="col-sm-6 p-1"><b>Purpose of Enquiry </b>: <?php echo $row->purpose_e ?></span>
					        </div>
					      </div>
					      <div class="modal-footer">
					        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
					      
					      </div>
					    </div>
					  </div>
					</div>

					  <?php
					  $i++;
					  				  }
					   ?>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

</body>
</html>


<!-- Modal -->