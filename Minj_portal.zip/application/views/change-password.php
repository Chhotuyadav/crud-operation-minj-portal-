<?php

  if( !isset($_SESSION['id_']) ){
    redirect(base_url(),'refresh');
    die();
  }
  ?>
<div class="home-background">
  <div class="container">
    <div class="row">
      <div class="col-sm-3 bar_">
        <a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" class=" rounded-3 p-1 text-decoration-none"><i class="bi bi-list bi-lg py-2 p-1"></i>⏪  ⏩</a>
        <?php include('include/sidebar.php') ?>
      </div>
      <div class="col-sm-9 home_">
        <h3>Chnage Password</h3>
        <form class="form_" method="post" action="<?= base_url('data/change_password');?>">
        <div class="row mt-3 mb-3">
          <div class="col-sm-4">
            <label class="mb-2 mt-2" for="change_password">Password:</label>
            <input type="text" name="change_password" id="password" class="form-control" onkeyup='check();' placeholder="Please Enter Password" required>
          </div>

          <div class="col-sm-4">
            <label class="mb-2 mt-2" for="change_password">Confirm Password:</label>
            <input type="text" name="confirm_pass" class="form-control" id="confirm_password" onkeyup='check();' placeholder="Confirm Password" required>
          </div>

          <div class="col-sm-4">
          <span id='message'></span>
          </div>
        </div>
           <input type="submit" name="save" value="Submit" class="btn btn-primary mb-3 mt-3">
        </form>
      </div>
    </div>
  </div>
</div>
</body>
</html>
