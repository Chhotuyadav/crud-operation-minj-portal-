    <?php

	if( !isset($_SESSION['id_']) ){
		redirect(base_url(),'refresh');
		die();
	}
	?>

	<?php
		if (empty($data)) {
			echo "<script>alert('No Result Find !!')</script>";
			redirect('registration','refresh');
		}
		else{
	?>

<div class="home-background">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 bar_">
				<a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" class=" rounded-3 p-1 text-decoration-none"><i class="bi bi-list bi-lg py-2 p-1"></i>⏪  ⏩</a>
				<?php include('include/sidebar.php') ?>
			</div>
			<div class="col-sm-9 home_">
				<h3>Search Student</h3>
					<div style="overflow-x:auto;">
						    <table  border="0" mt-3 cellspacing="5" cellpadding="5">
							  <tr style="background:#CCC">
							    <th>Sr No</th>
							    <th>Status</th>
							    <th>Name</th>
							    <th>Contact No.</th>
							   	<th>Email</th>
							  	<th>View</th>
							   	<th>Action</th>

							   
							  </tr>
							  	<?php
							   	$i=1;
							    foreach($data as $row){
							 
							          echo "<tr>";
							          echo "<td>".$i."</td>";
									  echo "<td>". $row->register_for."</td>";
									  echo "<td>".$row->name."</td>";
									  echo "<td>".$row->number."</td>";
									  echo "<td>".$row->email."</td>";
									  echo "<td><button class='btn btn-primary btn-sm'  data-bs-toggle='modal' data-bs-target='#model$row->id'>View More</button></td>"; 
									  echo "<td><button class='btn btn-primary btn-sm'  data-bs-toggle='modal' data-bs-target='#model1$row->id'>Edit</button></td>";        
									  echo "</tr>";


							   
								   ?>
 								<!-- Modal -->

					<div class="modal fade bd-example-modal-lg" id="model<?echo $row->id ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
					  <div class="modal-dialog modal-lg">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title" id="exampleModalLabel">Students Details</h5>
					        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					      </div>
					      <div class="modal-body" style="padding-left: 60px; !important">
					      	<div class="row"> 
					      	 <span class="col-sm-6 p-1"><img src="<?php echo base_url().'uploads/register/'.$row->image ?>" width="100" height="120"></span> 
					      	 <span class="col-sm-6 p-1"></span>
						     <span class="col-sm-6 p-1"><b>Status</b> : <?php echo $row->register_for ?></span>
						     <span class="col-sm-6 p-1"><b>Student Name </b> : <?php echo $row->name ?></span>
						     <span class="col-sm-6 p-1"><b>Contact No.</b>: <?php echo $row->number ?></span>
						     <span class="col-sm-6 p-1"><b>Father's Name</b> : <?php echo $row->f_name ?></span>
						     <span class="col-sm-6 p-1"><b>Mother's Name</b> : <?php echo $row->m_name ?></span>
						     <span class="col-sm-6 p-1"><b>Date Of Birth </b>: <?php echo $row->dob ?></span>
						     <span class="col-sm-6 p-1"><b>Gender </b>: <?php echo $row->gender ?></span>
						     <span class="col-sm-6 p-1"><b>Category </b>: <?php echo $row->category ?></span>
						     <span class="col-sm-6 p-1"><b>Qualification</b>: <?php echo $row->qualification ?></span>
					         <span class="col-sm-6 p-1"><b>Native Place </b>: <?php echo $row->native_p ?></span>
						     <span class="col-sm-6 p-1"><b>Enquiry Date </b>: <?php echo $row->enquiry_d ?></span>
						     <span class="col-sm-6 p-1"><b>Reference </b>: <?php echo $row->reference ?></span>
						     <span class="col-sm-6 p-1"><b>Pref. of Time </b>: <?php echo $row->pr_time ?></span>
						     <span class="col-sm-6 p-1"><b>Expected DOJ </b>: <?php echo $row->doj ?></span>
						     <span class="col-sm-6 p-1"><b>Right Now </b>: <?php echo $row->right_now ?></span>
						     <span class="col-sm-6 p-1"><b>Select Courses </b>: <?php echo $row->courses ?></span>
						     <span class="col-sm-6 p-1"><b>Enquiry Through </b>: <?php echo $row->enquiry_t ?></span>
						     <span class="col-sm-6 p-1"><b>Follow Up Date </b>: <?php echo $row->follow_d ?></span>
						     <span class="col-sm-6 p-1"><b>Course Fee </b>: <?php echo $row->course_fee ?></span>
						     <span class="col-sm-6 p-1"><b>Select University </b>: <?php echo $row->university ?></span>
						     <span class="col-sm-6 p-1"><b>Remark </b>: <?php echo $row->remark ?></span>
						     <span class="col-sm-6 p-1"><b>Purpose of Enquiry </b>: <?php echo $row->purpose_e ?></span>
						     <span class="col-sm-6 p-1"><b>Expected DOJ</b>: <?php echo $row->expected_date ?></span>
						     <span class="col-sm-6 p-1"><b>Payment Mode </b>: <?php echo $row->payment_mode ?></span> 
						     <span class="col-sm-6 p-1"><b>Fee After Discount </b>: <?php echo $row->fee_after_discount ?></span> 
						     <span class="col-sm-6 p-1"><b>Paid So Far </b>: <?php echo $row->paid_so_for ?></span> 
						     <span class="col-sm-6 p-1"><b>Discount% </b>: <?php echo $row->discount_per ?></span> 
						     <span class="col-sm-6 p-1"><b>Due Amount </b>: <?php echo $row->due_amount ?></span> 
						     <span class="col-sm-6 p-1"><b>Working </b>: <?php echo $row->working ?></span> 
						     <span class="col-sm-6 p-1"><b>Due Date</b>: <?php echo $row->due_date ?></span> 
						     <span class="col-sm-6 p-1"><b>Received Notes</b>: <?php echo $row->received_node ?></span> 
						     <span class="col-sm-6 p-1"><b>Pref. Of Time</b>: <?php echo $row->pref_of_time ?></span> 
						     <span class="col-sm-6 p-1"><b>CDS </b>: <?php echo $row->CDS ?></span> 
						     <span class="col-sm-6 p-1"><b>Registration Date </b>: <?php echo $row->registration_date ?></span> 
						     <span class="col-sm-6 p-1"><b>Courses End On Date </b>: <?php echo $row->course_end_on_date ?></span> 
						    
					        </div>
					      </div>
					      <div class="modal-footer">
					        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
					      
					      </div>
					    </div>
					  </div>
					</div>


						<div class="modal fade bd-example-modal-lg" id="model1<?echo $row->id ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
					  <div class="modal-dialog modal-lg">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title" id="exampleModalLabel">Students Details</h5>
					        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					      </div>
					         <div class="modal-body" style="padding-left: 60px; !important">
					      	
					      	   <form method="post" action="<?php echo base_url(' ');?>">
												  
		                              <div class="row">
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Status</b></label>
									       <select name="gender" class="form-control">
													<option value="<?php echo $row->register_for ?>"><?php echo $row->register_for ?></option>
									       			<?php
									       			
									       			if ($row->register_for== 'New Student') {
													
													echo'<option value="Enquiry Student">Enquiry Student</option>';
																							       				
									       			}
									       			else{

													echo '<option value="New Student">New Student</option>';
									       			}
									       			
													?>

											</select>
									     
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>Student Name</b></label>
									     <input type="text" name="name" class="form-control" value="<?php echo $row->name ?>">
									    </div>
									  </div>
								
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Contact No.</b></label>
									      <input type="text" name="number" class="form-control" value="<?php echo $row->number ?>">
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>Father's Name</b></label>
									     <input type="text" name="f_name" class="form-control" value="<?php echo $row->f_name ?>">
									    </div>
									  </div>
								
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Mother's Name</b></label>
									      <input type="text" name="m_name" class="form-control" value="<?php echo $row->m_name ?>">
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>Date Of Birth</b> </label>
									     <input type="text" name="dob" class="form-control" value="<?php echo $row->dob ?>">
									    </div>
									  </div>
								
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Gender</b></label>
									             	<select name="gender" class="form-control">
													<option value="<?php echo $row->gender ?>"><?php echo $row->gender ?></option>
													<option value="Male">Male</option>
													<option value="Female">Female</option>
											</select>
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>Category</b></label>
									     <input type="text" name="category" class="form-control" value="<?php echo $row->category ?>">
									    </div>
									  </div>
								
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Qualification</b></label>
									      <input type="text" name="qualification" class="form-control" value="<?php echo $row->qualification ?>">
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>Native Place</b></label>
									     <input type="text" name="native_p" class="form-control" value="<?php echo $row->native_p ?>">
									    </div>
									  </div>
								
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Enquiry Date</b> </label>
									      <input type="text" name="enquiry_d" class="form-control" value="<?php echo $row->enquiry_d ?>">
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>Reference</b></label>
									     <input type="text" name="reference" class="form-control" value="<?php echo $row->reference ?>">
									    </div>
									  </div>
								
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Pref. of Time</b></label>
									      <input type="text" name="pr_time" class="form-control" value="<?php echo $row->pr_time ?>">
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>Expected DOJ</b></label>
									     <input type="text" name="doj" class="form-control" value="<?php echo $row->doj ?>">
									    </div>
									  </div>
								
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Right Now</b></label>
									      <input type="text" name="right_now" class="form-control" value="<?php echo $row->right_now ?>">
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>Select Courses</b></label>
									     <input type="text" name="courses" class="form-control" value="<?php echo $row->courses ?>">
									    </div>
									  </div>
								
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Enquiry Through</b></label>
									      <input type="text" name="enquiry_t" class="form-control" value="<?php echo $row->enquiry_t ?>">
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>Follow Up Date</b></label>
									     <input type="text" name="follow_d" class="form-control" value="<?php echo $row->follow_d ?>">
									    </div>
									  </div>
								
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Course Fee</b></label>
									      <input type="text" name="course_fee" class="form-control" value="<?php echo $row->course_fee ?>">
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>Select University</b></label>
									     <input type="text" name="university" class="form-control" value="<?php echo $row->university ?>">
									    </div>
									  </div>
								
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Remark</b></label>
									      <input type="text" name="remark" class="form-control" value="<?php echo $row->remark ?>">
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>Purpose of Enquiry</b></label>
									     <input type="text" name="purpose_e" class="form-control" value="<?php echo $row->purpose_e ?>">
									    </div>
									  </div>
								
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Payment Mode</b></label>
									      <input type="text" name="payment_mode" class="form-control" value="<?php echo $row->payment_mode ?>">
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>Fee After Discount</b></label>
									     <input type="text" name="fee_after_discount" class="form-control" value="<?php echo $row->fee_after_discount ?>">
									    </div>
									  </div>
								
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Paid So Far</b></label>
									      <input type="text" name="paid_so_for" class="form-control" value="<?php echo $row->paid_so_for ?>">
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>Discount%</b></label>
									     <input type="text" name="discount_per" class="form-control" value="<?php echo $row->discount_per ?>">
									    </div>
									  </div>
								
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Due Amount</b></label>
									      <input type="text" name="due_amount" class="form-control" value="<?php echo $row->due_amount ?>">
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>Working</b></label>
									     <input type="text" name="working" class="form-control" value="<?php echo $row->working ?>">
									    </div>
									  </div>
								
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Due Date</b></label>
									      <input type="text" name="due_date" class="form-control" value="<?php echo $row->due_date ?>">
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>Received Notes</b></label>
									     <input type="text" name="received_node" class="form-control" value="<?php echo $row->received_node ?>">
									    </div>
									  </div>
								
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Pref. Of Time</b></label>
									      <input type="text" name="pref_of_time" class="form-control" value="<?php echo $row->pref_of_time ?>">
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>CDS</b></label>
									     <input type="text" name="CDS" class="form-control" value="<?php echo $row->CDS ?>">
									    </div>
									  </div>
								
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_1" class="mt-3 mb-3"><b>Registration Date</b></label>
									      <input type="text" name="registration_date" class="form-control" value="<?php echo $row->registration_date ?>">
									    </div>
									  </div>
									  <div class="col-md-4">
									    <div class="form-group">
									      <label for="glossary_entry_input_2" class="mt-3 mb-3"><b>Course End On Date</b></label>
									     <input type="text" name="course_end_on_date" class="form-control" value="<?php echo $row->course_end_on_date ?>">
									    </div>
									  </div>
								</div>
                          <div class="modal-footer">
					        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
					        <button type="submit" name="save" class="btn btn-secondary" >Update</button>
					      </div>
						    </form>
					        </div>
					      </div>
					      
					    </div>
					  </div>
						  <?php
						  $i++;
						  }
						   ?>
						</table>
					</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>

<?php
}
?>

