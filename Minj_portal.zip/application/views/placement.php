<?php

	if( !isset($_SESSION['id_']) ){
		redirect(base_url(),'refresh');
		die();
	}
	?>
<div class="home-background">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 bar_">
				<a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" class=" rounded-3 p-1 text-decoration-none"><i class="bi bi-list bi-lg py-2 p-1"></i>⏪  ⏩</a>
				<?php include('include/sidebar.php') ?>
			</div>
			<div class="col-sm-9 home_">
				<h3>Placement</h3>

				<form class="form_" method="post" action="<?= base_url('data/placment') ?>">
					<h3>Add Student</h3>
				<div class="row mt-3 mb-3">
					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Student Name">Student Name:</label>
						<input type="text" name="Student_name" class="form-control">
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Contact No">Contact No:</label>
						<input type="text" name="contact_no" class="form-control">
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Batch Time">Selected Desired Profile:</label>
						<input type="text" name="selected_desired_profile" class="form-control">
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Company Name">Selected Company Name:</label>
						<input type="text" name="select_company_name" class="form-control">
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Batch id">Batch Id:</label>
						<input type="text" name="batch_id" class="form-control">
					</div>
					

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Interview date">Interview Date:</label>
						<input type="date" name="interview_date" class="form-control">
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Selected">Selected:</label><br>
						<input type="radio" name="selected_yesno" value="YES"><label for="YES">&nbsp;YES</label>
						<input type="radio" name="selected_yesno" value="No"><label for="No">&nbsp;NO</label>
					</div>

					<input type="text" hidden  name="date_" value="<?php echo date('y-m-d') ?>">

				</div>
					 <input type="submit" name="save" value="Submit" class="btn btn-primary mb-3 mt-3">
				</form>


				<form class="form_" method="post" action="<?= base_url('data/c_opening') ?>">
					<h3>Current Opening</h3>
				<div class="row mt-3 mb-3">
					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Batch Id">Company Name</label>
						<input type="text" name="company_name" class="form-control">
					</div>
					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Batch Time">Desired Profile:</label>
						<input type="text" name="desired_profile" class="form-control">
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Batch Name">Date:</label>
						<input type="date" name="date_" class="form-control">
					</div>


				</div>
					 <input type="submit" name="save" value="Submit" class="btn btn-primary mb-3 mt-3">
				</form>
			</div>
		</div>
	</div>
</div>
</body>
</html>
