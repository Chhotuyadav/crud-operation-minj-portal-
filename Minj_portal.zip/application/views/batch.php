<?php

	if( !isset($_SESSION['id_']) ){
		redirect(base_url(),'refresh');
		die();
	}
	?>
<div class="home-background">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 bar_">
				<a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" class=" rounded-3 p-1 text-decoration-none"><i class="bi bi-list bi-lg py-2 p-1"></i>⏪  ⏩</a>
				<?php include('include/sidebar.php') ?>
			</div>
			<div class="col-sm-9 home_">
				<h3>Batch</h3>
				<form class="form_" method="post" action="<?= base_url('data/batch');?>" enctype="multipart/form-data">
				<div class="row mt-3 mb-3">
					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Batch Id">Batch Id:</label>
						<input type="text" name="batch_id" class="form-control" required>
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Batch Name">Batch Name:</label>
						<input type="text" name="batch_name" class="form-control" required>
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Batch Time">Batch Time:</label>
						<input type="text" name="batch_time" class="form-control" required>
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Batch Sarting Date">Batch Starting Date:</label>
						<input type="text" name="batch_strating_time" class="form-control" required>
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Duration">Duration:</label>
						<input type="text" name="duration" class="form-control" required>
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Courses">Courses:</label>
						<input type="text" name="course" class="form-control" required>
					</div>

					<div class="col-sm-4">
						<label class="mb-2 mt-2" for="Faculty Name">Faculty Name:</label>
						<input type="text" name="faculty" class="form-control" required>
					</div>

					<div class="col-sm-6">
						<label class="mb-2 mt-2" for="Upload Batch Photos">Upload Batch Photos:</label>
						<input type="file" name="upload_batch_photo" class="form-control" required>
					</div>

				</div>
					 <input type="submit" name="save" value="Submit" class="btn btn-primary mb-3 mt-3" >
				</form>
			</div>
		</div>
	</div>
</div>
</body>
</html>