<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'data/index';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['home'] = 'welcome/home';
$route['enquiry']= 'welcome/enquiry';
$route['pay-fee']= 'welcome/payfee';
$route['registration']= 'welcome/registration';
$route['follow-up']= 'welcome/fellowup';
$route['batch']= 'welcome/batch';
$route['placement']= 'welcome/placement';
$route['feedback']= 'welcome/feedback';
$route['change-password']= 'welcome/change_password';

/*admin sidebar*/
$route['due-payment-remainder']= 'welcome/due_payment_remainder';
$route['enquiry-follow-up']= 'welcome/enquiry_follow_up';
$route['placment-line-up-remainder']= 'welcome/placment_line_up_remainder';
$route['certificate-note']= 'welcome/certificate_note';
$route['contact-details']= 'welcome/contact_details';
$route['add-courses']= 'welcome/add_courses';
$route['add-university']= 'welcome/add_university';
$route['view-registration']= 'welcome/view_registration';
$route['view-batched']= 'welcome/view_batched';
$route['view-feedback']= 'welcome/view_feedback';
$route['view-placement']= 'welcome/view_placement';
$route['view-current-opening']= 'welcome/view_current_opening';
$route['view-important-contact']= 'welcome/view_important_contact';
$route['view-and-delete-status']= 'welcome/view_and_delete_status';
$route['view-payment']= 'welcome/view_payment';
$route['upload-edit-delete-images']= 'welcome/upload_edit_delete_images';
$route['insert-update-delete-news']= 'welcome/data_insert_update_delete_news';
$route['insert-update-delete-brochure']= 'welcome/data_insert_update_delete_brochure';
$route['update-note']= 'welcome/update_note';

//search
$route['search-student']= 'welcome/search_student';

/*insert data*/

//$route['index'] = 'data/login';

