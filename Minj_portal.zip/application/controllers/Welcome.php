<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct(){

		parent::__construct();

		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->database();
		$this->load->helper('url');
		$this->load->model('User');
	}

	 /*private function logged_in()
    {
        if( ! $this->session->userdata('authenticated')){
            redirect('login');
        }
    }*/

    

	public function home(){
		$this->load->view('include/header');
		$this->load->view('home');
		$this->load->view('include/footer');
	}

	public function enquiry(){
		$this->load->view('include/header');
		$this->load->view('enquiry');
		$this->load->view('include/footer');
	}

	public function payfee(){
		$this->load->view('include/header');
		$this->load->view('pay-fee');
		$this->load->view('include/footer');
	}

	public function registration(){
			$this->load->view('include/header');
			$this->load->view('registration');
			$this->load->view('include/footer');
		}

//fellow up
	public function fellowup(){
		$this->load->view('include/header');
		$this->load->view('follow-up');
		$this->load->view('include/footer');
	}

	public function batch(){
		$this->load->view('include/header');
		$this->load->view('batch');
		$this->load->view('include/footer');
	}

	public function placement(){
		$this->load->view('include/header');
		$this->load->view('placement');
		$this->load->view('include/footer');
	}

	public function feedback(){
		$this->load->view('include/header');
		$this->load->view('feedback');
		$this->load->view('include/footer');
	}

	//chang pass

	public function change_password(){
		$this->load->view('include/header');
		$this->load->view('change-password');
		$this->load->view('include/footer');
	}

	/*admin sidebar*/

	public function due_payment_remainder(){
		$result['data']=$this->User->get_due_payment_remainder();
		$this->load->view('include/header');
		$this->load->view('admin-sidebar/due-payment-remainder',$result);
		$this->load->view('include/footer');	
	}

	public function enquiry_follow_up(){
		$result['data']=$this->User->enquiry_data_display();

		$this->load->view('include/header');
		$this->load->view('admin-sidebar/enquiry-follow-up',$result);
		$this->load->view('include/footer');	
	}

	public function placment_line_up_remainder(){
		$result['data']= $this->User->get_placment_line_up_remainder_date();
		$this->load->view('include/header');
		$this->load->view('admin-sidebar/placment-line-up-remainder',$result);
		$this->load->view('include/footer');	
	}

	public function certificate_note(){
		$result['data']=$this->User->certificate_note_get();
		$this->load->view('include/header');
		$this->load->view('admin-sidebar/certificate-note',$result);
		$this->load->view('include/footer');	
	}

	public function contact_details(){
		$result['data']=$this->User->get_contact_details();
		$this->load->view('include/header');
		$this->load->view('admin-sidebar/contact-details',$result);
		$this->load->view('include/footer');	
	}

	public function add_courses(){
		$this->load->view('include/header');
		$this->load->view('admin-sidebar/add-courses');
		$this->load->view('include/footer');	
	}

	public function add_university(){
		$this->load->view('include/header');
		$this->load->view('admin-sidebar/add-university');
		$this->load->view('include/footer');	
	}

	public function view_registration(){
		$result['data']=$this->User->get_view_registration();
		$this->load->view('include/header');
		$this->load->view('admin-sidebar/view-registration',$result);
		$this->load->view('include/footer');	
	}

	public function view_batched(){
		$result['data']=$this->User->get_view_batch();
		$this->load->view('include/header');
		$this->load->view('admin-sidebar/view-batched',$result);
		$this->load->view('include/footer');	
	}

	public function view_feedback(){
		$result['data']=$this->User->get_view_feedback();
		$this->load->view('include/header');
		$this->load->view('admin-sidebar/view-feedback',$result);
		$this->load->view('include/footer');	
	}

	public function view_placement(){
		$result['data']=$this->User->get_view_placement();
		$this->load->view('include/header');
		$this->load->view('admin-sidebar/view-placement',$result);
		$this->load->view('include/footer');	
	}

	public function view_current_opening(){
		$result['data']=$this->User->get_view_current_opening();
		$this->load->view('include/header');
		$this->load->view('admin-sidebar/view-current-opening',$result);
		$this->load->view('include/footer');	
	}

	public function view_important_contact(){
		$this->load->view('include/header');
		$this->load->view('admin-sidebar/view-important-contact');
		$this->load->view('include/footer');	
	}



	public function view_payment(){
		$result['data']=$this->User->get_view_payment();
		$this->load->view('include/header');
		$this->load->view('admin-sidebar/view-payment',$result);
		$this->load->view('include/footer');	
	}


	public function upload_edit_delete_images(){
		$result['data']=$this->User->get_student();
		$this->load->view('include/header');
		$this->load->view('admin-sidebar/upload-edit-delete-images',$result);
		$this->load->view('include/footer');	
	}

	public function data_insert_update_delete_brochure(){
		$result['data']=$this->User->brochure_get();
		$this->load->view('include/header');
		$this->load->view('admin-sidebar/insert-update-delete-brochure',$result);
		$this->load->view('include/footer');	
	}

	public function update_note(){
		$result['data']=$this->User->notes_get();
		$this->load->view('include/header');
		$this->load->view('admin-sidebar/update-note',$result);
		$this->load->view('include/footer');	
	}

	

//update_register
  //       public function update_register(){
		// $result['data']=$this->User->update_register();
		// $this->load->view('include/header');
		// $this->load->view('admin-sidebar/update_register',$result);
		// $this->load->view('include/footer');


	// /search-student

	public function search_student(){
		if ($this->input->post('save')) {
		$name= $this->input->post('name');
		$number=$this->input->post('number');
		$result['data'] = $this->User->register_search($name,$number);
		if (!empty($result)) {
			$this->load->view('include/header');
			$this->load->view('search-student',$result);
			$this->load->view('include/footer');		
		}
		else{
			echo "<script>alert('No Result Find !!')</script>";
			redirect('registration','refresh');

		}
		
	}
}







}


