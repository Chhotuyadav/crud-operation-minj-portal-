<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Data extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();

		$this->load->helper('form');
		$this->load->database();
		$this->load->helper('url');
		$this->load->model('User');
		$this->load->library(array('pagination', 'session','email'));

	}


		public function index()	{
			$this->load->view('include/header');
			$this->load->view('login');
			$this->load->view('include/footer');
		}

	/*login*/

		public function login_user(){
			$email = $this->input->post('email');
			$password = $this->input->post('password');
			$result = $this->User->login_user($email,$password);
			if($result){
					$this->session->set_userdata('id_',$result);
					/*print_r($_SESSION['id_']);
					die();*/
          echo "<script>alert('Login Successfully!!')</script>";
					redirect('home','refresh');

      }else{
          echo "<script>alert('Login Failed Details Not Matched!!')</script>";
		 			redirect(base_url(),'refresh');
      		
      }
		}

		//logout

			public function logout(){
				$this->session->unset_userdata('id_');
				$this->session->sess_destroy();
				redirect(base_url(),'refresh');
			}

			//forgot_pass

			public function forgot_pass(){
				$email = $this->input->post('email_forgote');

				$result = $this->User->forgot_email($email);

				if (empty($result)) {
          echo "<script>alert('Email is  Not Registerd!!')</script>";
		 			redirect(base_url(),'refresh');
						
				}
				else{
					foreach ($result as $row ) {
					 
						    $config = Array(
						  'protocol' => 'smtp',
						  'smtp_host' => 'ssl://smtp.googlemail.com',
						  'smtp_port' => 465,
						  'smtp_user' => 'kanika.systos04@gmail.com', // change it to yours
						  'smtp_pass' => 'systos04@k', // change it to yours
						  'mailtype' => 'html',
						  'charset' => 'iso-8859-1',
						  'wordwrap' => TRUE
						);

						        $message = 'Your Password :-'.$row->password;
						      $this->load->library('email', $config);
						      $this->email->set_newline("\r\n");
						      $this->email->from('kanika.systos04@gmail.com'); // change it to yours
						      $this->email->to($email);// change it to yours
						      $this->email->subject('Forgot Password | Minj Education');
						      $this->email->message($message);
						      if($this->email->send())
						     {
						      echo "<script> alert('Password Sent to your Email!') </script>";
				       	 	redirect('home', 'refresh');
						     }
						     else
						    {
						     show_error($this->email->print_debugger());
						    }


					}
		}
	}

	//change_password

	public function change_password(){
		$password = $this->input->post('change_password');

		$result = $this->User->change_password($password);

				if ($result=true) {
					echo "<script> alert('Password Changed Successfully!') </script>";
					redirect('home', 'refresh');
				}

			}

	/*enqueiry*/

	public function savedata()
	{
		
		if($this->input->post('save'))
		{
		    $data['name']=$this->input->post('name');
			$data['number']=$this->input->post('number');
			$data['f_name']=$this->input->post('f_name');
			$data['m_name']=$this->input->post('m_name');
			$data['dob']=$this->input->post('dob');
			$data['gender']=$this->input->post('gender');
			$data['gender']=$this->input->post('gender');
			$data['category']=$this->input->post('category');
			$data['qualification']=$this->input->post('qualification');
			$data['email']=$this->input->post('email');
			$data['native_p']=$this->input->post('native_p');
			$data['enquiry_d']=$this->input->post('enquiry_d');
			$data['reference']=$this->input->post('reference');
			$data['pr_time']=$this->input->post('pr_time');
			$data['doj']=$this->input->post('doj');
			$data['right_now']=$this->input->post('right_now');
			$data['courses']=$this->input->post('courses');
			$data['enquiry_t']=$this->input->post('enquiry_t');
			$data['follow_d']=$this->input->post('follow_d');
			$data['course_fee']=$this->input->post('course_fee');
			$data['university']=$this->input->post('university');
			$data['remark']=$this->input->post('remark');
			$data['purpose_e']=$this->input->post('purpose_e');
			$data['date']=$this->input->post('date');

			$response=$this->User->saverecords($data);
			if($response==true){
			        echo "<script> alert('Enquiry Data Inserted!') </script>";
			       	 redirect('enquiry', 'refresh');
			}
			else{
			        echo "<script> alert('Error!! Not Inserted Data.') </script>";
					 redirect('enquiry', 'refresh');
			}
		}
	}

	/*PAY FEE*/
	public function payfee(){

		if ($this->input->post('save')) {
			
			$data['student_name']=$this->input->post('student_name');
			$data['course_fee']=$this->input->post('course_fee');
			$data['batch_id']=$this->input->post('batch_id');
			$data['discount']=$this->input->post('discount');
			$data['instalation_date']=$this->input->post('instalation_date');
			$data['fee_after_discount']=$this->input->post('fee_after_discount');
			$data['gender']=$this->input->post('gender');
			$data['remaining_amount']=$this->input->post('remaining_amount');
			$data['native_p_']=$this->input->post('native_p_');
			$data['Payment_mode']=$this->input->post('Payment_mode');
			$data['course']=$this->input->post('course');
			$data['paid_so_for']=$this->input->post('paid_so_for');
			$data['contact_nu']=$this->input->post('contact_nu');
			$data['due_amount']=$this->input->post('due_amount');
			$data['email_id']=$this->input->post('email_id');
			$data['due_date']=$this->input->post('due_date');
			$data['date']=$this->input->post('date');

			$payfee =$this->User->savepayfee($data);
			if ($payfee == true) {
				echo "<script>alert('Payfee Successfully Inserted!!')</script>";
			       	 redirect('pay-fee', 'refresh');
			}
			else{
				echo "<script>alert('Error Payfee Not Inserted!!')</script>";
			       	 redirect('pay-fee', 'refresh');	
			}

		}

	}

	/*batch*/

	public function batch(){
		if ($this->input->post('save')) {

			$image_name = 'blank';

      if (isset($_FILES['upload_batch_photo']['name'])) {
        if ($_FILES['upload_batch_photo']['name'] != '') {
          $image_name = $_FILES['upload_batch_photo']['name'];
          $target_dir = "uploads/uploadbatch/";
          $target_file = $target_dir . basename($_FILES["upload_batch_photo"]["name"]);
          move_uploaded_file($_FILES["upload_batch_photo"]["tmp_name"], $target_file);
        }
        
      }
      else{
        		echo "<script>alert('File Uploading hase been Failed!!')</script>";

        }
			
			$data['batch_id']=$this->input->post('batch_id');
			$data['batch_name']=$this->input->post('batch_name');
			$data['batch_time']=$this->input->post('batch_time');
			$data['batch_strating_time']=$this->input->post('batch_strating_time');
			$data['duration']=$this->input->post('duration');
			$data['course']=$this->input->post('course');
			$data['faculty']=$this->input->post('faculty');
			$data['upload_batch_photo']=$image_name;

			$batch =$this->User->batch($data);
			if ($batch == true) {
				echo "<script>alert('Batch Successfully Inserted!!')</script>";
				redirect('batch','refresh');
			}
			else{
				echo "<script>alert('Batch Not Inserted!!')</script>";
				redirect('batch','refresh');
			}


		}
	}


	// fellow_up

		public function fellow_up(){
			if ($this->input->post('save')) {
				$data['student_name'] = $this->input->post('student_name'); 
				$data['student_status'] = $this->input->post('student_status'); 
				$data['select_course'] = $this->input->post('select_course');
				$data['remark'] = $this->input->post('remark');
				$data['date'] = $this->input->post('date');

				print_r($data);
				//die();

				$result = $this->User->fellow_up($data);
				if ($result == true) {
						echo "<script>alert('Fellow Up Successfully Inserted!!')</script>";
						redirect('follow-up','refresh');	 	
				 }
				 else{
						echo "<script>alert('Error Fellow Up Not Inserted!!')</script>";
						redirect('follow-up','refresh');	 	
				 } 
			}
		}


	//placment

	public function placment(){
		if ($this->input->post('save')) {
			$data['date_']= $this->input->post('date_');
			$data['Student_name'] = $this->input->post('Student_name');
			$data['contact_no'] = $this->input->post('contact_no');
			$data['selected_desired_profile'] = $this->input->post('selected_desired_profile');
			$data['select_company_name'] = $this->input->post('select_company_name');
			$data['batch_id'] = $this->input->post('batch_id');
			$data['interview_date'] = $this->input->post('interview_date');
			$data['selected_yesno'] = $this->input->post('selected_yesno');
			$placment = $this->User->placment($data);

			if ($placment == true) {
				echo "<script>alert('Placment Successfully Inserted!!')</script>";
				redirect('placement','refresh');
			}
			else{
				echo "<script>alert('Placment Not Inserted!!')</script>";
				redirect('placement','refresh');
			}
		}


	}
     


	//current opining

	public function c_opening(){
		if ($this->input->post('save')) {
			$data['company_name'] = $this->input->post('company_name');
			$data['desired_profile'] = $this->input->post('desired_profile');
			$data['date_'] = $this->input->post('date_');

			$opining = $this->User->c_opening($data);

			if ($opining == true) {
				echo "<script>alert('Current  Opining Successfully Inserted!!')</script>";
				redirect('placement','refresh');
			}
			else{
				echo "<script>alert('Current  Opining Not Inserted!!')</script>";
				redirect('placement','refresh');
			}
		}


	}


	//feedback

	public function feedback(){
		if ($this->input->post('save')) {
			$data['student_name']= $this->input->post('student_name');
			$data['contact_number']= $this->input->post('contact_number');
			$data['if_intrested_in_any']= $this->input->post('if_intrested_in_any');
			$data['desire_profile']= $this->input->post('desire_profile');
			$data['refernces_if_any_name']= $this->input->post('refernces_if_any_name');
			$data['refernces_if_any_contact']= $this->input->post('refernces_if_any_contact');
			$data['trading_yesno']= $this->input->post('trading_yesno');

			$feedback= $this->User->feedback($data);
			if ($feedback == true) {
				echo "<script>alert('feedback Successfully Inserted!!')</script>";
				redirect('feedback','refresh');
			}
			else{
				echo "<script>alert('feedback Not Inserted!!')</script>";
				redirect('feedback','refresh');
			}		
			
		}
	}

	//brochure

	//delete
			public function delete_data(){

					 $id = $this->uri->segment(3);

           $detele =$this->User->delete_data($id);  
           if ($detele == true) {
           		echo "<script>alert(' Brochure Delete Successfully !!')</script>";
							redirect('insert-update-delete-brochure','refresh');
           }
           else{
           	echo "<script>alert('Data Delete Failed !!')</script>";
							redirect('insert-update-delete-brochure','refresh');
           }
			}

			/*image*/
 	public function brochure(){

 		if ($this->input->post('save')) {

 			//image

 			$image_name = 'blank';

          if (isset($_FILES['brochure_image']['name'])) {
            if ($_FILES['brochure_image']['name'] != '') {
              $image_name = $_FILES['brochure_image']['name'];
              $target_dir = "uploads/brochure/";
              $target_file = $target_dir . basename($_FILES["brochure_image"]["name"]);
              move_uploaded_file($_FILES["brochure_image"]["tmp_name"], $target_file);
            }
          }

          //die();

			$sat= $this->input->post('status');

          	$data  = array('brochure_image' => $image_name,
          					'status' => $sat,

          	 );

			$do_upload= $this->User->do_upload($data);
			if ($do_upload == true) {
				echo "<script>alert('Brochure Successfully Inserted!!')</script>";
				redirect('insert-update-delete-brochure','refresh');
			}
			else{
				echo "<script>alert('Brochure Not Inserted!!')</script>";
				redirect('insert-update-delete-brochure','refresh');
			}
			
		}

 	}

 	/*end*/

 	//notes

 		public function notes(){

 		if ($this->input->post('save')) {

 			//image

 			$notes = 'blank';

          if (isset($_FILES['notes']['name'])) {
            if ($_FILES['notes']['name'] != '') {
              $notes = $_FILES['notes']['name'];
              $target_dir = "uploads/note/";
              $target_file = $target_dir . basename($_FILES["notes"]["name"]);
              move_uploaded_file($_FILES["notes"]["tmp_name"], $target_file);
            }
          }

          //die();

			$course= $this->input->post('course');
			$category= $this->input->post('category');

          	$data  = array('notes' => $notes,
          					'course' => $course,
          					'category' => $category,

          	 );

			$uplode_note= $this->User->uplode_note($data);
			if ($uplode_note == true) {
				echo "<script>alert('Notes Successfully Inserted!!')</script>";
				redirect('update-note','refresh');
			}
			else{
				echo "<script>alert('Notes Not Inserted!!')</script>";
				redirect('update-note','refresh');
			}
			
		}

 	}

 	//delete nots

	 	 public function delete_notes(){
	 	 		$id = $this->uri->segment(3);

           $detele_note =$this->User->delete_notes($id);  
           if ($detele_note == true) {
           		echo "<script>alert('Notes Delete Successfully !!')</script>";
							redirect('update-note','refresh');
           }
           else{
           	echo "<script>alert(' Delete Failed !!')</script>";
							redirect('update-note','refresh');
           }
	 	 }


 	//testiminials

	 	public function testiminials(){

	 		if ($this->input->post('save')) {

	 			//image

	 			$student_image = 'blank';

          if (isset($_FILES['student_image']['name'])) {
            if ($_FILES['student_image']['name'] != '') {
              $student_image = $_FILES['student_image']['name'];
              $target_dir = "uploads/student/";
              $target_file = $target_dir . basename($_FILES["student_image"]["name"]);
              move_uploaded_file($_FILES["student_image"]["tmp_name"], $target_file);
            }
          }

          //die();

          	$data  = array('student_image' => $student_image,
                  	 );

			$student= $this->User->student($data);
			if ($student == true) {
				echo "<script>alert('Student Image Successfully Inserted!!')</script>";
				redirect('upload-edit-delete-images','refresh');
			}
			else{
				echo "<script>alert('Student Image Not Inserted!!')</script>";
				redirect('upload-edit-delete-images','refresh');
			}
			
		}

 	}


 	//delete_sudent

	 	 public function delete_student(){
		 	 		$id = $this->uri->segment(3);

	           $detele_note =$this->User->delete_student($id);  
	           if ($detele_note == true) {
	           		echo "<script>alert('Student Delete Successfully !!')</script>";
								redirect('upload-edit-delete-images','refresh');
	           }
	           else{
	           	echo "<script>alert(' Delete Failed !!')</script>";
								redirect('upload-edit-delete-images','refresh');
	           }
		 	 }

		 	 //certified_note


		 	 public function certified_note(){
		 	 	if ($this->input->post('save')) {
		 	 		$data['student_name']= $this->input->post('student_name');
		 	 		$data['course_name']= $this->input->post('course_name');
		 	 		$data['certificate_no']= $this->input->post('certificate_no');
		 	 		$data['Result'] = $this->input->post('Result');
		 	 		$data['date']= $this->input->post('date');
		 	 		$data['remark']= $this->input->post('remark');

		 	 		$result = $this->User->certified_note($data);
		 	 		if ($result == true) {
		 	 			 			echo "<script>alert('Certified Note Inserted!!')</script>";
									redirect('certificate-note');
					}else{
		 	 			 			echo "<script>alert('Error Not Inserted!!')</script>";
									redirect('certificate-note');

		 	 			 		}
		 	 	}
		 	 }


		 	 //important_details

		 	 public function important_details(){
		 	 	if ($this->input->post('save')) {
		 	 		$data['name']=$this->input->post('name');
		 	 		$data['contact_no']=$this->input->post('contact_no');
		 	 		$data['email_id']=$this->input->post('email_id');
		 	 		$data['profile']=$this->input->post('profile');

		 	 		$result= $this->User->important_details($data);
		 	 		if ($result == true) {
		 	 					echo "<script>alert('Important Details Successfully Inserted !!')</script>";
								redirect('contact-details','refresh');
		 	 		}
		 	 		else{
		 	 					echo "<script>alert('Error Not Inserted !!')</script>";
								redirect('contact-details','refresh');
		 	 		}
		 	 	}
		 	 }
		 	 
		 	 //delete_contact
		 	 
		 	 public function delete_contact(){
		 	    
		 	    $id = $this->uri->segment(3);

           $delete_contact =$this->User->delete_contact($id);  
           if ($delete_contact == true) {
           		echo "<script>alert('Contact Delete Successfully !!')</script>";
				redirect('contact-details','refresh');
           }
           else{
	           	echo "<script>alert(' Delete Failed !!')</script>";
				redirect('contact-details','refresh');
           }
		 	 }
		 	 
		 	 //delete_note


		 	 public function delete_note(){
		 	    
		 	    $id = $this->uri->segment(3);

           $delete_note =$this->User->delete_note($id);  
           if ($delete_note == true) {
           		echo "<script>alert('Certified Note Delete Successfully !!')</script>";
				redirect('certificate-note','refresh');
           }
           else{
	           	echo "<script>alert(' Delete Failed !!')</script>";
				redirect('certificate-note','refresh');
           }
		 	 }


		 	 //delete_batch


		 	 public function delete_batch(){
		 	    
		 	    $id = $this->uri->segment(3);

           $delete_batch =$this->User->delete_batch($id);  
           if ($delete_batch == true) {
           		echo "<script>alert('Batch Delete Successfully !!')</script>";
				redirect('view-batched','refresh');
           }
           else{
	           	echo "<script>alert(' Delete Failed !!')</script>";
				redirect('view-batched','refresh');
           }
		 	 }


		 	 //delete_feedback

		 	  public function delete_feedback(){
		 	    
		 	    $id = $this->uri->segment(3);

           $delete_feedback =$this->User->delete_feedback($id);  
           if ($delete_feedback == true) {
           		echo "<script>alert('feedback Delete Successfully !!')</script>";
				redirect('view-feedback','refresh');
           }
           else{
	           	echo "<script>alert(' Delete Failed !!')</script>";
				redirect('view-feedback','refresh');
           }
		 	 }


		 	 //delete_placement

		 	 public function delete_placement(){
		 	    
		 	    $id = $this->uri->segment(3);

           $delete_placement =$this->User->delete_placement($id);  
           if ($delete_placement == true) {
           		echo "<script>alert('Placement Delete Successfully !!')</script>";
				redirect('view-placement','refresh');
           }
           else{
	           	echo "<script>alert(' Delete Failed !!')</script>";
				redirect('view-placement','refresh');
           }
		 	 }

		 	 //delete_certificate_note

		 	  public function delete_certificate_note(){
		 	    
		 	    $id = $this->uri->segment(3);

           $delete_certificate_note =$this->User->delete_certificate_note($id);  
           if ($delete_certificate_note == true) {
           		echo "<script>alert('Certificate Note Delete Successfully !!')</script>";
							redirect('certificate-note','refresh');
           }
           else{
	           	echo "<script>alert(' Delete Failed !!')</script>";
				redirect('certificate-note','refresh');
           }
		 	 }





			//delete_current_opening

		 	  public function delete_current_opening(){
		 	    
		 	    $id = $this->uri->segment(3);

           $delete_current_opening =$this->User->delete_current_opening($id);  
           if ($delete_current_opening == true) {
           		echo "<script>alert('Placement Delete Successfully !!')</script>";
							redirect('view-placement','refresh');
           }
           else{
	           	echo "<script>alert(' Delete Failed !!')</script>";
				redirect('view-placement','refresh');
           }
		 	 }


		 	 //register 


		 	 public  function register(){
		 	 	if ($this->input->post('save')){
		 	 		$data['register_for'] = $this->input->post('register_for');
		 	 		$data['name'] = $this->input->post('student_name');
		 	 		$data['number'] = $this->input->post('contact_nu');
		 	 		$data['m_name'] = $this->input->post('mother_name');
		 	 		$data['dob'] = $this->input->post('dob');
		 	 		$data['gender'] = $this->input->post('gender');
		 	 		$data['category'] = $this->input->post('category');
		 	 		$data['qualification'] = $this->input->post('education');
		 	 		$data['email'] = $this->input->post('email_id');
		 	 		$data['native_p'] = $this->input->post('native_p_');
		 	 		$data['courses'] = $this->input->post('course');
		 	 		$data['reference'] = $this->input->post('refrence');
		 	 		$data['univercity'] = $this->input->post('univercity');
		 	 		$data['expected_date'] = $this->input->post('expected_date');
		 	 		$data['payment_mode'] = $this->input->post('payment_mode');
		 	 		$data['fee_after_discount'] = $this->input->post('fee_after_discount');
		 	 		$data['course_fee'] = $this->input->post('course_fee');
		 	 		$data['paid_so_for'] = $this->input->post('paid_so_for');
		 	 		$data['discount_per'] = $this->input->post('discount_per');
		 	 		$data['due_amount'] = $this->input->post('due_amount');
		 	 		$data['working'] = $this->input->post('working');
		 	 		$data['due_date'] = $this->input->post('due_date');
		 	 		$data['right_now'] = $this->input->post('right_now');
		 	 		$data['received_node'] = $this->input->post('received_node');
		 	 		$data['pref_of_time'] = $this->input->post('pref_of_time');
		 	 		$data['CDS'] = $this->input->post('CDS');
		 	 		$data['registration_date'] = $this->input->post('registration_date');
		 	 		$data['remark'] = $this->input->post('remark');
		 	 		$data['course_end_on_date'] = $this->input->post('course_end_on_date');
		 	 		$data['date'] = $this->input->post('date');



          $student_image = 'blank';

          if (isset($_FILES['image_register']['name'])) {
            if ($_FILES['image_register']['name'] != '') {
              $student_image = $_FILES['image_register']['name'];
              $target_dir = "uploads/register/";
              $target_file = $target_dir . basename($_FILES["image_register"]["name"]);
              move_uploaded_file($_FILES["image_register"]["tmp_name"], $target_file);
            }
          }

          $data['image']=$student_image;

          $result = $this->User->register($data);

          if ($result == true) {
          		echo "<script>alert('Student Successfully Registerd!!')</script>";
							redirect('registration','refresh');
          }
          else{
          		echo "<script>alert('Error Not Registerd !!')</script>";
							redirect('registration','refresh');
          }

		 	 	}
		 	 }



		 	 //update_register

		 	 


		 	 public function update_register(){
		 	 	if ($this->input->post('save')) {

		 	 	$data['register_for'] = $this->input->post('register_for');
				$data['name'] = $this->input->post('name');
				$data['number'] = $this->input->post('number');
				$data['f_name'] = $this->input->post('f_name');
				$data['m_name'] = $this->input->post('m_name');
				$data['dob'] = $this->input->post('dob');
				$data['gender'] = $this->input->post('gender');
				$data['category'] = $this->input->post('category');
				$data['qualification'] = $this->input->post('qualification');
				$data['native_p'] = $this->input->post('native_p');
				$data['enquiry_d'] = $this->input->post('enquiry_d');
				$data['reference'] = $this->input->post('reference');
				$data['pr_time'] = $this->input->post('pr_time');
				$data['doj'] = $this->input->post('doj');
				$data['right_now'] = $this->input->post('right_now');
				$data['courses'] = $this->input->post('courses');
				$data['enquiry_t'] = $this->input->post('enquiry_t');
				$data['follow_d'] = $this->input->post('follow_d');
				$data['course_fee'] = $this->input->post('course_fee');
				$data['university'] = $this->input->post('university');
				$data['remark'] = $this->input->post('remark');
				$data['purpose_e'] = $this->input->post('purpose_e');
				$data['payment_mode'] = $this->input->post('payment_mode');
				$data['fee_after_discount'] = $this->input->post('fee_after_discount');
				$data['paid_so_for'] = $this->input->post('paid_so_for');
				$data['discount_per'] = $this->input->post('discount_per');
				$data['due_amount'] = $this->input->post('due_amount');
				$data['working'] = $this->input->post('working');
				$data['due_date'] = $this->input->post('due_date');
				$data['received_node'] = $this->input->post('received_node');
				$data['pref_of_time'] = $this->input->post('pref_of_time');
				$data['CDS'] = $this->input->post('CDS');
				$data['registration_date'] = $this->input->post('registration_date');
				$data['course_end_on_date'] = $this->input->post('course_end_on_date');
				$id = $this->input->post('id');

		/*		print_r($data);
				die();
*/

				$result= $this->User->update_register($data,$id);
					if ($result == true) {
          		echo "<script>alert('Update Successfully !!')</script>";
							redirect('view-registration','refresh');
          }
          else{
          		echo "<script>alert('Error Not Update !!')</script>";
							redirect('view-registration','refresh');
          }
				}
				
		 	 }

		 	 //delete_view_register

		 	 public function delete_view_register($id){
		 		$result = $this->User->delete_view_register($id);
		 		if($result==true){
		 			echo "<script>alert('Deleted Successfully !!')</script>";
							redirect('view-registration','refresh');
		 		}
		 		else{
          		echo "<script>alert('Error Not Delete!!')</script>";
							redirect('view-registration','refresh');
          }
		 	 }

		 	 //main_search






		
}




?>
