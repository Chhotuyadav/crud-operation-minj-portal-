/*header script*/
$(document).ready(function(){
	$('.nav-link').click(function() {
	$('.nav-link').removeClass('active');
	$(this).addClass('active');
	});
});
/*header script*/

/*sidebar*/
$(document).ready(function(){ 
$('.not_active').on('click', function(){
    $('.not_active').removeClass('current');
    $(this).addClass('current');
});
});
/*sideabar*/


  var check = function() {
  if (document.getElementById('password').value ==
    document.getElementById('confirm_password').value) {
    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = 'Password Matched';
  } else {
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'Password Not Matched';
  }
}